import { sql } from "drizzle-orm";
import {
  index,
  integer,
  sqliteTable,
  text,
  uniqueIndex,
} from "drizzle-orm/sqlite-core";

export const tournamentConfig = sqliteTable("tournament_config", {
  id: integer("id").primaryKey(),
  tournamentName: text("tournament_name").notNull(),
  season: text("season").notNull(),
  schoolName: text("school_name").notNull(),
  areaResponsible: text("area_responsible").notNull(),
  rector: text("rector").notNull(),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const sports = sqliteTable("sports", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  active: integer("active", { mode: "boolean" }).notNull().default(true),
  winPoints: integer("win_points").notNull().default(3),
  drawPoints: integer("draw_points").notNull().default(1),
  lossPoints: integer("loss_points").notNull().default(0),
  allowDraw: integer("allow_draw", { mode: "boolean" }).notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const categories = sqliteTable(
  "categories",
  {
    id: text("id").primaryKey(),
    name: text("name").notNull(),
    sortOrder: integer("sort_order").notNull().default(0),
    active: integer("active", { mode: "boolean" }).notNull().default(true),
    createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [uniqueIndex("idx_categories_name").on(table.name)],
);

export const teams = sqliteTable(
  "teams",
  {
    id: text("id").primaryKey(),
    categoryId: text("category_id")
      .notNull()
      .references(() => categories.id, { onDelete: "restrict" }),
    sportId: text("sport_id")
      .notNull()
      .references(() => sports.id, { onDelete: "restrict" }),
    parallel: text("parallel").notNull(),
    name: text("name").notNull(),
    captain: text("captain").notNull().default(""),
    teacher: text("teacher").notNull().default(""),
    jerseyColor: text("jersey_color").notNull().default("#1c6b51"),
    rosterJson: text("roster_json").notNull().default("[]"),
    createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [
    uniqueIndex("idx_teams_category_sport_parallel").on(
      table.categoryId,
      table.sportId,
      table.parallel,
    ),
    index("idx_teams_category_sport").on(table.categoryId, table.sportId),
  ],
);

export const draws = sqliteTable(
  "draws",
  {
    id: text("id").primaryKey(),
    categoryId: text("category_id")
      .notNull()
      .references(() => categories.id, { onDelete: "restrict" }),
    sportId: text("sport_id")
      .notNull()
      .references(() => sports.id, { onDelete: "restrict" }),
    format: text("format").notNull().default("round_robin"),
    teamCount: integer("team_count").notNull(),
    createdBy: text("created_by").notNull(),
    createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [index("idx_draws_category_sport").on(table.categoryId, table.sportId)],
);

export const matches = sqliteTable(
  "matches",
  {
    id: text("id").primaryKey(),
    drawId: text("draw_id").references(() => draws.id, { onDelete: "set null" }),
    categoryId: text("category_id")
      .notNull()
      .references(() => categories.id, { onDelete: "restrict" }),
    sportId: text("sport_id")
      .notNull()
      .references(() => sports.id, { onDelete: "restrict" }),
    phase: text("phase").notNull().default("round_robin"),
    roundNo: integer("round_no").notNull().default(1),
    roundLabel: text("round_label").notNull().default("Fecha 1"),
    homeTeamId: text("home_team_id").references(() => teams.id, {
      onDelete: "restrict",
    }),
    awayTeamId: text("away_team_id").references(() => teams.id, {
      onDelete: "restrict",
    }),
    matchDate: text("match_date"),
    matchTime: text("match_time"),
    venue: text("venue").notNull().default("Por asignar"),
    status: text("status").notNull().default("pending"),
    scoreHome: integer("score_home"),
    scoreAway: integer("score_away"),
    detailJson: text("detail_json").notNull().default("{}"),
    winnerOverride: text("winner_override").references(() => teams.id, {
      onDelete: "restrict",
    }),
    notes: text("notes").notNull().default(""),
    createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [
    index("idx_matches_category_sport_phase_round").on(
      table.categoryId,
      table.sportId,
      table.phase,
      table.roundNo,
    ),
    index("idx_matches_status_date").on(table.status, table.matchDate, table.matchTime),
  ],
);

export const auditLog = sqliteTable(
  "audit_log",
  {
    id: text("id").primaryKey(),
    action: text("action").notNull(),
    matchId: text("match_id").references(() => matches.id, {
      onDelete: "set null",
    }),
    actorId: text("actor_id").notNull(),
    actorEmail: text("actor_email").notNull(),
    beforeJson: text("before_json").notNull().default("{}"),
    afterJson: text("after_json").notNull().default("{}"),
    createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [index("idx_audit_log_created_at").on(table.createdAt)],
);

export const appUsers = sqliteTable(
  "app_users",
  {
    email: text("email").primaryKey(),
    displayName: text("display_name").notNull(),
    role: text("role", { enum: ["master", "docente"] }).notNull().default("docente"),
    active: integer("active", { mode: "boolean" }).notNull().default(true),
    createdByEmail: text("created_by_email").notNull(),
    createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [index("idx_app_users_active_role").on(table.active, table.role)],
);

export const registrations = sqliteTable(
  "registrations",
  {
    id: text("id").primaryKey(),
    categoryId: text("category_id").notNull().references(() => categories.id, { onDelete: "restrict" }),
    sportId: text("sport_id").notNull().references(() => sports.id, { onDelete: "restrict" }),
    parallel: text("parallel").notNull(),
    teamName: text("team_name").notNull(),
    teacherName: text("teacher_name").notNull(),
    captain: text("captain").notNull(),
    contactPhone: text("contact_phone").notNull(),
    contactEmail: text("contact_email").notNull().default(""),
    rosterJson: text("roster_json").notNull().default("[]"),
    payerName: text("payer_name").notNull(),
    amountCents: integer("amount_cents").notNull(),
    paymentMethod: text("payment_method").notNull(),
    paymentDate: text("payment_date").notNull(),
    paymentReference: text("payment_reference").notNull().default(""),
    proofObjectKey: text("proof_object_key").notNull(),
    proofName: text("proof_name").notNull(),
    proofType: text("proof_type").notNull(),
    proofSize: integer("proof_size").notNull(),
    status: text("status", { enum: ["pending", "processing", "approved", "rejected"] }).notNull().default("pending"),
    decisionNote: text("decision_note").notNull().default(""),
    createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    reviewedBy: text("reviewed_by"),
    reviewedAt: text("reviewed_at"),
    teamId: text("team_id").references(() => teams.id, { onDelete: "set null" }),
  },
  (table) => [
    index("idx_registrations_status_created").on(table.status, table.createdAt),
    index("idx_registrations_team").on(table.categoryId, table.sportId, table.parallel),
    uniqueIndex("idx_registrations_proof_key").on(table.proofObjectKey),
  ],
);
