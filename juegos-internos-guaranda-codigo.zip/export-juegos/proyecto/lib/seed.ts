export async function seedTournamentDefaults(db: D1Database) {
  await db
    .prepare(
      `INSERT OR IGNORE INTO tournament_config
       (id, tournament_name, season, school_name, area_responsible, rector)
       VALUES (1, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET tournament_name = excluded.tournament_name, season = excluded.season
       WHERE tournament_config.tournament_name = 'Juegos Internos 2026' AND tournament_config.season = '2026'`,
    )
    .bind("Juegos Internos 2026–2027", "2026–2027", "Unidad Educativa Guaranda", "Licenciada Paola Prado", "Fernando Villares")
    .run();

  await db.batch([
    db.prepare("INSERT OR IGNORE INTO sports (id, name, active, win_points, draw_points, loss_points, allow_draw, sort_order) VALUES (?, ?, 1, ?, ?, ?, ?, ?)").bind("futbol", "Fútbol", 3, 1, 0, 1, 1),
    db.prepare("INSERT OR IGNORE INTO sports (id, name, active, win_points, draw_points, loss_points, allow_draw, sort_order) VALUES (?, ?, 1, ?, ?, ?, ?, ?)").bind("basquet", "Básquet", 2, 0, 1, 0, 2),
    db.prepare("UPDATE sports SET active = 0 WHERE id = 'ecuavoley'"),
  ]);

  const categoryCount = await db.prepare("SELECT COUNT(*) AS total FROM categories").first<{ total: number }>();
  if (!categoryCount?.total) {
    const defaults = [
      ["8vo", "8.º año", 8],
      ["9no", "9.º año", 9],
      ["10mo", "10.º año", 10],
      ["1ro-bgu", "1.º BGU", 11],
      ["2do-bgu", "2.º BGU", 12],
      ["3ro-bgu", "3.º BGU", 13],
    ];
    await db.batch(defaults.map(([id, name, order]) =>
      db.prepare("INSERT OR IGNORE INTO categories (id, name, sort_order, active) VALUES (?, ?, ?, 1)").bind(id, name, order),
    ));
  }
}
