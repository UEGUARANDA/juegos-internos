export type StandingTeam = {
  id: string;
  name: string;
  parallel: string;
  jerseyColor?: string;
};

export type StandingMatch = {
  categoryId: string;
  sportId: string;
  phase: string;
  status: string;
  homeTeamId: string | null;
  awayTeamId: string | null;
  scoreHome: number | null;
  scoreAway: number | null;
};

export type StandingRules = {
  id: string;
  winPoints: number;
  drawPoints: number;
  lossPoints: number;
  allowDraw: boolean | number;
};

export type StandingRow = StandingTeam & {
  played: number;
  wins: number;
  draws: number;
  losses: number;
  scored: number;
  conceded: number;
  difference: number;
  points: number;
};

function matchPoints(
  match: StandingMatch,
  teamId: string,
  rules: StandingRules,
) {
  if (match.scoreHome === null || match.scoreAway === null) return 0;
  const isHome = match.homeTeamId === teamId;
  const own = isHome ? match.scoreHome : match.scoreAway;
  const other = isHome ? match.scoreAway : match.scoreHome;
  if (own > other) return rules.winPoints;
  if (own < other) return rules.lossPoints;
  return rules.drawPoints;
}

function headToHead(
  leftId: string,
  rightId: string,
  matches: StandingMatch[],
  rules: StandingRules,
) {
  const direct = matches.find(
    (match) =>
      match.phase === "round_robin" &&
      match.status === "finished" &&
      ((match.homeTeamId === leftId && match.awayTeamId === rightId) ||
        (match.homeTeamId === rightId && match.awayTeamId === leftId)),
  );
  if (!direct) return 0;
  const leftPoints = matchPoints(direct, leftId, rules);
  const rightPoints = matchPoints(direct, rightId, rules);
  return leftPoints === rightPoints ? 0 : leftPoints > rightPoints ? 1 : -1;
}

export function calculateStandings(
  teams: StandingTeam[],
  allMatches: StandingMatch[],
  rules: StandingRules,
): StandingRow[] {
  const rows = new Map<string, StandingRow>();
  for (const team of teams) {
    rows.set(team.id, {
      ...team,
      played: 0,
      wins: 0,
      draws: 0,
      losses: 0,
      scored: 0,
      conceded: 0,
      difference: 0,
      points: 0,
    });
  }

  const finished = allMatches.filter(
    (match) =>
      match.phase === "round_robin" &&
      match.status === "finished" &&
      match.homeTeamId &&
      match.awayTeamId &&
      match.scoreHome !== null &&
      match.scoreAway !== null,
  );

  for (const match of finished) {
    const home = rows.get(match.homeTeamId as string);
    const away = rows.get(match.awayTeamId as string);
    if (!home || !away) continue;
    home.played += 1;
    away.played += 1;
    home.scored += match.scoreHome as number;
    home.conceded += match.scoreAway as number;
    away.scored += match.scoreAway as number;
    away.conceded += match.scoreHome as number;

    if (match.scoreHome === match.scoreAway) {
      home.draws += 1;
      away.draws += 1;
      home.points += rules.drawPoints;
      away.points += rules.drawPoints;
    } else if ((match.scoreHome as number) > (match.scoreAway as number)) {
      home.wins += 1;
      away.losses += 1;
      home.points += rules.winPoints;
      away.points += rules.lossPoints;
    } else {
      away.wins += 1;
      home.losses += 1;
      away.points += rules.winPoints;
      home.points += rules.lossPoints;
    }
  }

  for (const row of rows.values()) row.difference = row.scored - row.conceded;

  return [...rows.values()].sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    const direct = headToHead(a.id, b.id, finished, rules);
    if (direct) return -direct;
    if (b.difference !== a.difference) return b.difference - a.difference;
    if (b.scored !== a.scored) return b.scored - a.scored;
    return a.name.localeCompare(b.name, "es");
  });
}

