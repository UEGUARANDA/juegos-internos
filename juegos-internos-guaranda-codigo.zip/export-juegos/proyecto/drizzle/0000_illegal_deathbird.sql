CREATE TABLE `app_users` (
	`email` text PRIMARY KEY NOT NULL,
	`display_name` text NOT NULL,
	`role` text DEFAULT 'docente' NOT NULL,
	`active` integer DEFAULT true NOT NULL,
	`created_by_email` text NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_app_users_active_role` ON `app_users` (`active`,`role`);--> statement-breakpoint
CREATE TABLE `audit_log` (
	`id` text PRIMARY KEY NOT NULL,
	`action` text NOT NULL,
	`match_id` text,
	`actor_id` text NOT NULL,
	`actor_email` text NOT NULL,
	`before_json` text DEFAULT '{}' NOT NULL,
	`after_json` text DEFAULT '{}' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`match_id`) REFERENCES `matches`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `idx_audit_log_created_at` ON `audit_log` (`created_at`);--> statement-breakpoint
CREATE TABLE `categories` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`sort_order` integer DEFAULT 0 NOT NULL,
	`active` integer DEFAULT true NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_categories_name` ON `categories` (`name`);--> statement-breakpoint
CREATE TABLE `draws` (
	`id` text PRIMARY KEY NOT NULL,
	`category_id` text NOT NULL,
	`sport_id` text NOT NULL,
	`format` text DEFAULT 'round_robin' NOT NULL,
	`team_count` integer NOT NULL,
	`created_by` text NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON UPDATE no action ON DELETE restrict,
	FOREIGN KEY (`sport_id`) REFERENCES `sports`(`id`) ON UPDATE no action ON DELETE restrict
);
--> statement-breakpoint
CREATE INDEX `idx_draws_category_sport` ON `draws` (`category_id`,`sport_id`);--> statement-breakpoint
CREATE TABLE `matches` (
	`id` text PRIMARY KEY NOT NULL,
	`draw_id` text,
	`category_id` text NOT NULL,
	`sport_id` text NOT NULL,
	`phase` text DEFAULT 'round_robin' NOT NULL,
	`round_no` integer DEFAULT 1 NOT NULL,
	`round_label` text DEFAULT 'Fecha 1' NOT NULL,
	`home_team_id` text,
	`away_team_id` text,
	`match_date` text,
	`match_time` text,
	`venue` text DEFAULT 'Por asignar' NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`score_home` integer,
	`score_away` integer,
	`detail_json` text DEFAULT '{}' NOT NULL,
	`winner_override` text,
	`notes` text DEFAULT '' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`draw_id`) REFERENCES `draws`(`id`) ON UPDATE no action ON DELETE set null,
	FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON UPDATE no action ON DELETE restrict,
	FOREIGN KEY (`sport_id`) REFERENCES `sports`(`id`) ON UPDATE no action ON DELETE restrict,
	FOREIGN KEY (`home_team_id`) REFERENCES `teams`(`id`) ON UPDATE no action ON DELETE restrict,
	FOREIGN KEY (`away_team_id`) REFERENCES `teams`(`id`) ON UPDATE no action ON DELETE restrict,
	FOREIGN KEY (`winner_override`) REFERENCES `teams`(`id`) ON UPDATE no action ON DELETE restrict
);
--> statement-breakpoint
CREATE INDEX `idx_matches_category_sport_phase_round` ON `matches` (`category_id`,`sport_id`,`phase`,`round_no`);--> statement-breakpoint
CREATE INDEX `idx_matches_status_date` ON `matches` (`status`,`match_date`,`match_time`);--> statement-breakpoint
CREATE TABLE `sports` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`active` integer DEFAULT true NOT NULL,
	`win_points` integer DEFAULT 3 NOT NULL,
	`draw_points` integer DEFAULT 1 NOT NULL,
	`loss_points` integer DEFAULT 0 NOT NULL,
	`allow_draw` integer DEFAULT true NOT NULL,
	`sort_order` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE `teams` (
	`id` text PRIMARY KEY NOT NULL,
	`category_id` text NOT NULL,
	`sport_id` text NOT NULL,
	`parallel` text NOT NULL,
	`name` text NOT NULL,
	`captain` text DEFAULT '' NOT NULL,
	`teacher` text DEFAULT '' NOT NULL,
	`jersey_color` text DEFAULT '#1c6b51' NOT NULL,
	`roster_json` text DEFAULT '[]' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON UPDATE no action ON DELETE restrict,
	FOREIGN KEY (`sport_id`) REFERENCES `sports`(`id`) ON UPDATE no action ON DELETE restrict
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_teams_category_sport_parallel` ON `teams` (`category_id`,`sport_id`,`parallel`);--> statement-breakpoint
CREATE INDEX `idx_teams_category_sport` ON `teams` (`category_id`,`sport_id`);--> statement-breakpoint
CREATE TABLE `tournament_config` (
	`id` integer PRIMARY KEY NOT NULL,
	`tournament_name` text NOT NULL,
	`season` text NOT NULL,
	`school_name` text NOT NULL,
	`area_responsible` text NOT NULL,
	`rector` text NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
