CREATE TABLE `registrations` (
	`id` text PRIMARY KEY NOT NULL,
	`category_id` text NOT NULL,
	`sport_id` text NOT NULL,
	`parallel` text NOT NULL,
	`team_name` text NOT NULL,
	`teacher_name` text NOT NULL,
	`captain` text NOT NULL,
	`contact_phone` text NOT NULL,
	`contact_email` text DEFAULT '' NOT NULL,
	`roster_json` text DEFAULT '[]' NOT NULL,
	`payer_name` text NOT NULL,
	`amount_cents` integer NOT NULL,
	`payment_method` text NOT NULL,
	`payment_date` text NOT NULL,
	`payment_reference` text DEFAULT '' NOT NULL,
	`proof_object_key` text NOT NULL,
	`proof_name` text NOT NULL,
	`proof_type` text NOT NULL,
	`proof_size` integer NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`decision_note` text DEFAULT '' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`reviewed_by` text,
	`reviewed_at` text,
	`team_id` text,
	FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON UPDATE no action ON DELETE restrict,
	FOREIGN KEY (`sport_id`) REFERENCES `sports`(`id`) ON UPDATE no action ON DELETE restrict,
	FOREIGN KEY (`team_id`) REFERENCES `teams`(`id`) ON UPDATE no action ON DELETE set null
);
--> statement-breakpoint
CREATE INDEX `idx_registrations_status_created` ON `registrations` (`status`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_registrations_team` ON `registrations` (`category_id`,`sport_id`,`parallel`);--> statement-breakpoint
CREATE UNIQUE INDEX `idx_registrations_proof_key` ON `registrations` (`proof_object_key`);