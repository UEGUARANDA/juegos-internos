"use client";

import { Check, CheckCircle2, Clock3, Download, FileCheck2, FileText, LoaderCircle, RefreshCw, ShieldCheck, X } from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";

type Registration = {
  id: string;
  categoryId: string;
  sportId: string;
  parallel: string;
  teamName: string;
  teacherName: string;
  captain: string;
  contactPhone: string;
  contactEmail: string;
  roster: string[];
  payerName: string;
  amountCents: number;
  paymentMethod: string;
  paymentDate: string;
  paymentReference: string;
  proofName: string;
  proofSize: number;
  status: "pending" | "processing" | "approved" | "rejected";
  decisionNote: string;
  createdAt: string;
  reviewedBy: string | null;
  reviewedAt: string | null;
  categoryName: string;
  sportName: string;
  proofUrl: string;
};

type Filter = "pending" | "approved" | "rejected";

function money(cents: number) {
  return new Intl.NumberFormat("es-EC", { style: "currency", currency: "USD" }).format(cents / 100);
}

function dateLabel(value: string) {
  const date = new Date(value.includes("T") ? value : `${value}T12:00:00-05:00`);
  return new Intl.DateTimeFormat("es-EC", { dateStyle: "medium", timeZone: "America/Guayaquil" }).format(date);
}

export default function InscripcionesPanel({ onPendingChange }: { onPendingChange?: (count: number) => void }) {
  const [rows, setRows] = useState<Registration[]>([]);
  const [filter, setFilter] = useState<Filter>("pending");
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState("");
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  const refresh = useCallback(async () => {
    setError("");
    try {
      const response = await fetch("/api/inscripciones", { cache: "no-store" });
      const payload = await response.json() as { error?: string; registrations?: Registration[] };
      if (!response.ok) throw new Error(payload.error || "No se pudieron cargar las inscripciones.");
      const records = payload.registrations ?? [];
      setRows(records);
      onPendingChange?.(records.filter((row) => row.status === "pending").length);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "No se pudieron cargar las inscripciones.");
    } finally { setLoading(false); }
  }, [onPendingChange]);

  // Load server data when the Master opens the review panel.
  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(() => { void refresh(); }, [refresh]);

  const counts = useMemo(() => ({
    pending: rows.filter((row) => row.status === "pending").length,
    approved: rows.filter((row) => row.status === "approved").length,
    rejected: rows.filter((row) => row.status === "rejected").length,
  }), [rows]);
  const visibleRows = rows.filter((row) => row.status === filter);

  async function decide(registration: Registration, action: "approve" | "reject") {
    if (action === "approve" && !window.confirm(`¿Aprobar ${registration.teamName} en ${registration.sportName}? El equipo y la nómina se cargarán en Equipos.`)) return;
    if (action === "reject" && !window.confirm(`¿Marcar como no aprobada la solicitud de ${registration.teamName}?`)) return;
    setBusyId(registration.id);
    setNotice("");
    setError("");
    try {
      const response = await fetch("/api/inscripciones", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: registration.id, action, note: notes[registration.id] ?? "" }),
      });
      const payload = await response.json() as { error?: string; message?: string };
      if (!response.ok) throw new Error(payload.error || "No se pudo actualizar la solicitud.");
      setNotice(payload.message || "Solicitud actualizada.");
      await refresh();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "No se pudo actualizar la solicitud."); }
    finally { setBusyId(""); }
  }

  return <div className="registration-review">
    <div className="registration-review-banner"><span><ShieldCheck size={22} /></span><div><strong>Revisión privada del Master</strong><small>Los datos, la nómina y los comprobantes solo se muestran en esta cuenta.</small></div><button type="button" className="review-refresh" onClick={() => void refresh()} aria-label="Actualizar solicitudes"><RefreshCw size={16} /></button></div>
    <div className="registration-review-stats"><div><span>Pendientes</span><strong>{counts.pending}</strong></div><div><span>Aprobadas y cargadas</span><strong>{counts.approved}</strong></div><div><span>No aprobadas</span><strong>{counts.rejected}</strong></div></div>
    <div className="registration-review-toolbar"><div className="registration-review-tabs" role="tablist" aria-label="Filtrar inscripciones">
      {(["pending", "approved", "rejected"] as Filter[]).map((status) => <button type="button" role="tab" aria-selected={filter === status} className={filter === status ? "review-tab review-tab-active" : "review-tab"} key={status} onClick={() => setFilter(status)}>{status === "pending" ? "Por revisar" : status === "approved" ? "Aprobadas" : "No aprobadas"}<b>{counts[status]}</b></button>)}
    </div></div>
    {notice ? <div className="review-notice" role="status"><CheckCircle2 size={17} />{notice}</div> : null}
    {error ? <div className="review-error" role="alert">{error}</div> : null}
    {loading ? <div className="review-empty"><LoaderCircle className="registration-spin" size={22} /><strong>Cargando solicitudes</strong><span>Buscando inscripciones y comprobantes…</span></div>
      : visibleRows.length ? <div className="registration-review-list">{visibleRows.map((row) => <article className="registration-review-card" key={row.id}>
        <div className="review-card-heading"><div><span className={`review-status review-status-${row.status}`}><i />{row.status === "pending" ? "Por revisar" : row.status === "approved" ? "Aprobada" : "No aprobada"}</span><h3>{row.teamName} <span>· {row.sportName}</span></h3><small>{row.categoryName} · Paralelo {row.parallel} · Recibida {dateLabel(row.createdAt)}</small></div><b className="review-amount">{money(row.amountCents)}</b></div>
        <div className="review-detail-grid"><div><span>Docente responsable</span><strong>{row.teacherName}</strong></div><div><span>Capitán/a</span><strong>{row.captain}</strong></div><div><span>Contacto</span><strong>{row.contactPhone}{row.contactEmail ? ` · ${row.contactEmail}` : ""}</strong></div><div><span>Participantes</span><strong>{row.roster.length} estudiantes</strong></div></div>
        <details className="review-roster-details"><summary>Ver nómina del equipo</summary><ol>{row.roster.map((name, index) => <li key={`${name}-${index}`}>{name}{name.toLowerCase() === row.captain.toLowerCase() ? " · Capitán/a" : ""}</li>)}</ol></details>
        <div className="review-payment"><div><span>Pago</span><strong>{row.paymentMethod} · {dateLabel(row.paymentDate)} · Pagó: {row.payerName}</strong>{row.paymentReference ? <small>Referencia: {row.paymentReference}</small> : null}</div><a className="review-receipt-link" href={row.proofUrl}><FileText size={17} /><span><strong>Ver comprobante</strong><small>{row.proofName} · {(row.proofSize / 1024).toFixed(0)} KB</small></span><Download size={15} /></a></div>
        {row.status === "pending" ? <div className="review-decision"><label>Nota de revisión <span>(opcional)</span><input value={notes[row.id] ?? ""} onChange={(event) => setNotes((previous) => ({ ...previous, [row.id]: event.target.value }))} maxLength={300} placeholder="Observación para el registro interno" /></label><div><button type="button" className="review-reject-button" disabled={busyId === row.id} onClick={() => void decide(row, "reject")}><X size={16} />No aprobar</button><button type="button" className="review-approve-button" disabled={busyId === row.id} onClick={() => void decide(row, "approve")}>{busyId === row.id ? <LoaderCircle className="registration-spin" size={16} /> : <Check size={16} />}Aprobar y cargar equipo</button></div></div>
          : <div className="review-processed"><Clock3 size={15} /><span>{row.status === "approved" ? "Equipo y nómina cargados en Equipos" : `Solicitud no aprobada${row.decisionNote ? ` · ${row.decisionNote}` : ""}`}</span></div>}
      </article>)}</div> : <div className="review-empty"><span><FileCheck2 size={24} /></span><strong>{filter === "pending" ? "No hay solicitudes pendientes" : filter === "approved" ? "Aún no hay equipos aprobados" : "No hay solicitudes no aprobadas"}</strong><span>{filter === "pending" ? "Cuando envíen un formulario desde la página pública, aparecerá aquí." : "Las solicitudes de esta categoría aparecerán aquí."}</span></div>}
  </div>;
}
