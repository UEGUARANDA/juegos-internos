import GestionGate from "../gestion-gate";

export const dynamic = "force-dynamic";

export default function Gestion() {
  return <GestionGate />;
}
