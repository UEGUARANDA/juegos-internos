import { env } from "cloudflare:workers";

export const SESSION_COOKIE = "ueg_torneo_session";
const SESSION_LIFETIME_MS = 12 * 60 * 60 * 1000;
const PASSWORD_ITERATIONS = 100_000;
const encoder = new TextEncoder();

export type LocalSessionUser = {
  email: string;
  username: string;
  displayName: string;
  role: "master" | "docente";
  mustChangePassword: boolean;
};

type Database = D1Database;

function setting(name: string) {
  return (env as unknown as Record<string, string | undefined>)[name] ?? "";
}

export function normalizeUsername(value: unknown) {
  return typeof value === "string" ? value.trim() : "";
}

function toBase64Url(bytes: Uint8Array) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/g, "");
}

function fromBase64Url(value: string) {
  const base64 = value.replaceAll("-", "+").replaceAll("_", "/");
  const binary = atob(base64 + "=".repeat((4 - (base64.length % 4)) % 4));
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}

function randomBase64Url(byteLength: number) {
  const bytes = new Uint8Array(byteLength);
  crypto.getRandomValues(bytes);
  return toBase64Url(bytes);
}

export function createTemporaryPassword() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
  const random = new Uint32Array(16);
  crypto.getRandomValues(random);
  return Array.from(random, (value) => alphabet[value % alphabet.length]).join("");
}

export function newPasswordSalt() {
  return randomBase64Url(16);
}

export async function hashPassword(password: string, salt: string) {
  const key = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: fromBase64Url(salt), iterations: PASSWORD_ITERATIONS, hash: "SHA-256" },
    key,
    256,
  );
  return toBase64Url(new Uint8Array(bits));
}

export async function verifyPassword(password: string, salt: string, expectedHash: string) {
  const actualHash = await hashPassword(password, salt);
  const actual = encoder.encode(actualHash);
  const expected = encoder.encode(expectedHash);
  if (actual.length !== expected.length) return false;
  let difference = 0;
  for (let index = 0; index < actual.length; index += 1) difference |= actual[index] ^ expected[index];
  return difference === 0;
}

async function hashSessionToken(token: string) {
  return toBase64Url(new Uint8Array(await crypto.subtle.digest("SHA-256", encoder.encode(token))));
}

export async function ensureLocalAuthSchema(db: Database) {
  await db.prepare(`CREATE TABLE IF NOT EXISTS app_credentials (
    email TEXT PRIMARY KEY NOT NULL,
    username TEXT NOT NULL COLLATE NOCASE UNIQUE,
    password_salt TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    must_change_password INTEGER NOT NULL DEFAULT 1,
    FOREIGN KEY (email) REFERENCES app_users(email) ON DELETE CASCADE
  )`).run();
  await db.prepare(`CREATE TABLE IF NOT EXISTS app_sessions (
    token_hash TEXT PRIMARY KEY NOT NULL,
    email TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (email) REFERENCES app_users(email) ON DELETE CASCADE
  )`).run();
  await db.prepare("CREATE INDEX IF NOT EXISTS idx_app_sessions_email ON app_sessions(email)").run();
  await db.prepare(`CREATE TABLE IF NOT EXISTS auth_login_attempts (
    login_key TEXT PRIMARY KEY NOT NULL,
    failed_count INTEGER NOT NULL DEFAULT 0,
    window_started_at TEXT NOT NULL,
    locked_until TEXT
  )`).run();
  await db.prepare("DELETE FROM auth_login_attempts WHERE julianday(window_started_at) < julianday('now', '-1 day')").run();

  await initializeFirstMaster(db);
}

async function initializeFirstMaster(db: Database) {
  const username = normalizeUsername(setting("INITIAL_MASTER_USERNAME"));
  const email = setting("INITIAL_MASTER_EMAIL").trim().toLowerCase();
  const displayName = setting("INITIAL_MASTER_DISPLAY_NAME").trim() || "PAOLA PRADO";
  const temporaryPassword = setting("INITIAL_MASTER_PASSWORD");
  if (!username || !email || !temporaryPassword) return;

  const existingCredential = await db.prepare("SELECT email FROM app_credentials WHERE username = ? COLLATE NOCASE LIMIT 1")
    .bind(username).first<{ email: string }>();
  if (existingCredential) return;

  const existingUser = await db.prepare("SELECT email FROM app_users WHERE lower(email) = ? LIMIT 1")
    .bind(email).first<{ email: string }>();
  const salt = newPasswordSalt();
  const passwordHash = await hashPassword(temporaryPassword, salt);

  const accountEmail = existingUser?.email ?? email;
  if (existingUser) {
    await db.prepare("UPDATE app_users SET display_name = ?, role = 'master', active = 1 WHERE email = ?")
      .bind(displayName, accountEmail).run();
  } else {
    await db.prepare("INSERT INTO app_users (email, display_name, role, active, created_by_email) VALUES (?, ?, 'master', 1, ?)")
      .bind(email, displayName, email).run();
  }
  await db.prepare(`INSERT INTO app_credentials (email, username, password_salt, password_hash, must_change_password)
    VALUES (?, ?, ?, ?, 1)
    ON CONFLICT(email) DO UPDATE SET username = excluded.username, password_salt = excluded.password_salt,
      password_hash = excluded.password_hash, must_change_password = 1`)
    .bind(accountEmail, username, salt, passwordHash).run();
}

export async function getSessionUserByToken(db: Database, token: string | null | undefined): Promise<LocalSessionUser | null> {
  if (!token || token.length > 160) return null;
  const tokenHash = await hashSessionToken(token);
  const row = await db.prepare(`SELECT u.email, c.username, u.display_name AS displayName, u.role,
      u.active, c.must_change_password AS mustChangePassword
    FROM app_sessions s JOIN app_users u ON u.email = s.email
    JOIN app_credentials c ON c.email = u.email
    WHERE s.token_hash = ? AND julianday(s.expires_at) > julianday('now')
    LIMIT 1`).bind(tokenHash).first<{
      email: string;
      username: string;
      displayName: string;
      role: "master" | "docente";
      active: number;
      mustChangePassword: number;
    }>();
  if (!row || Number(row.active) !== 1) return null;
  return {
    email: row.email,
    username: row.username,
    displayName: row.displayName,
    role: row.role,
    mustChangePassword: Number(row.mustChangePassword) === 1,
  };
}

export async function getSessionUserFromCookieHeader(db: Database, cookieHeader: string | null) {
  const token = getCookie(cookieHeader ?? "", SESSION_COOKIE);
  return getSessionUserByToken(db, token);
}

export function getCookie(header: string, name: string) {
  for (const item of header.split(";")) {
    const separator = item.indexOf("=");
    if (separator < 0 || item.slice(0, separator).trim() !== name) continue;
    try {
      return decodeURIComponent(item.slice(separator + 1).trim());
    } catch {
      return null;
    }
  }
  return null;
}

export async function createSession(db: Database, email: string, requestUrl: string) {
  const token = randomBase64Url(32);
  const tokenHash = await hashSessionToken(token);
  const expiresAt = new Date(Date.now() + SESSION_LIFETIME_MS).toISOString();
  await db.prepare("INSERT INTO app_sessions (token_hash, email, expires_at) VALUES (?, ?, ?)")
    .bind(tokenHash, email, expiresAt).run();
  const secure = new URL(requestUrl).protocol === "https:" ? "; Secure" : "";
  const cookie = `${SESSION_COOKIE}=${encodeURIComponent(token)}; Path=/; Max-Age=${Math.floor(SESSION_LIFETIME_MS / 1000)}; HttpOnly; SameSite=Lax${secure}`;
  return { token, tokenHash, cookie };
}

export function expiredSessionCookie(requestUrl: string) {
  const secure = new URL(requestUrl).protocol === "https:" ? "; Secure" : "";
  return `${SESSION_COOKIE}=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax${secure}`;
}

export async function getLoginKey(username: string) {
  return hashSessionToken(username.trim().toLowerCase());
}
