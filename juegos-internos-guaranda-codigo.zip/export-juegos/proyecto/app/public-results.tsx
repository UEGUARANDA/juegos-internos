"use client";

import { useEffect, useMemo, useState } from "react";
import { Activity, ArrowRight, CalendarDays, Clock3, Download, Flag, Trophy, UsersRound, Volleyball } from "lucide-react";
import Link from "next/link";
import { calculateStandings } from "../lib/standings";
import Image from "next/image";
import InstallAppButton from "./pwa-install";

type PublicSport = {
  id: string;
  name: string;
  active: number | boolean;
  winPoints: number;
  drawPoints: number;
  lossPoints: number;
  allowDraw: number | boolean;
  sortOrder: number;
};
type PublicCategory = { id: string; name: string; sortOrder: number };
type PublicTeam = { id: string; categoryId: string; sportId: string; parallel: string; name: string; jerseyColor: string };
type PublicMatch = {
  id: string;
  categoryId: string;
  sportId: string;
  phase: string;
  roundNo: number;
  roundLabel: string;
  homeTeamId: string | null;
  awayTeamId: string | null;
  homeName: string | null;
  awayName: string | null;
  homeColor: string | null;
  awayColor: string | null;
  matchDate: string | null;
  matchTime: string | null;
  venue: string;
  status: string;
  scoreHome: number | null;
  scoreAway: number | null;
  categoryName: string;
  sportName: string;
};

export type PublicTournamentData = {
  config: {
    tournamentName: string;
    season: string;
    schoolName: string;
    areaResponsible: string;
    rector: string;
  };
  sports: PublicSport[];
  categories: PublicCategory[];
  teams: PublicTeam[];
  matches: PublicMatch[];
  unavailable: boolean;
};

function compareSchedule(a: PublicMatch, b: PublicMatch) {
  return `${a.matchDate ?? "9999-12-31"} ${a.matchTime ?? "23:59"}`.localeCompare(`${b.matchDate ?? "9999-12-31"} ${b.matchTime ?? "23:59"}`);
}

function dateLabel(value: string | null, style: "long" | "short" = "long") {
  if (!value) return "Fecha por asignar";
  return new Intl.DateTimeFormat("es-EC", style === "long"
    ? { weekday: "long", day: "numeric", month: "long", timeZone: "America/Guayaquil" }
    : { day: "numeric", month: "short", timeZone: "America/Guayaquil" })
    .format(new Date(`${value}T12:00:00-05:00`));
}

function RegistrationCountdown() {
  const [now, setNow] = useState(0);
  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const opensAt = Date.parse("2026-10-05T05:00:00Z");
  const closesAt = Date.parse("2026-10-10T05:00:00Z");
  const target = now < opensAt ? opensAt : closesAt;
  const remaining = Math.max(0, target - now);
  const days = Math.floor(remaining / 86_400_000);
  const hours = Math.floor((remaining % 86_400_000) / 3_600_000);
  const minutes = Math.floor((remaining % 3_600_000) / 60_000);
  const seconds = Math.floor((remaining % 60_000) / 1000);
  const state = now >= closesAt ? "closed" : now < opensAt ? "before" : "open";

  return <div className={`event-countdown event-countdown-${state}`} aria-live="polite">
    <div className="event-countdown-copy"><span>{state === "closed" ? "INSCRIPCIONES CERRADAS" : state === "before" ? "APERTURA DE INSCRIPCIONES EN" : "CIERRE DE INSCRIPCIONES EN"}</span><strong>{state === "closed" ? "¡Gracias por participar!" : state === "before" ? "Del 5 al 9 de octubre" : "Último día: 9 de octubre"}</strong></div>
    {state !== "closed" ? <div className="event-countdown-clock" aria-label={`${days} días, ${hours} horas, ${minutes} minutos, ${seconds} segundos`}>
      <span><b>{String(days).padStart(2, "0")}</b><small>días</small></span><i>:</i><span><b>{String(hours).padStart(2, "0")}</b><small>hrs</small></span><i>:</i><span><b>{String(minutes).padStart(2, "0")}</b><small>min</small></span><i>:</i><span><b>{String(seconds).padStart(2, "0")}</b><small>seg</small></span>
    </div> : null}
  </div>;
}

export default function PublicResults({ data }: { data: PublicTournamentData }) {
  const [categoryId, setCategoryId] = useState(data.categories[0]?.id ?? "");
  const [sportId, setSportId] = useState(data.sports[0]?.id ?? "");
  const category = data.categories.find((item) => item.id === categoryId) ?? data.categories[0];
  const sport = data.sports.find((item) => item.id === sportId) ?? data.sports[0];
  const teams = useMemo(() => data.teams.filter((team) => team.categoryId === category?.id && team.sportId === sport?.id), [data.teams, category?.id, sport?.id]);
  const matches = useMemo(() => data.matches.filter((match) => match.categoryId === category?.id && match.sportId === sport?.id), [data.matches, category?.id, sport?.id]);
  const standings = sport ? calculateStandings(teams, matches, sport) : [];
  const finished = matches.filter((match) => match.status === "finished");
  const pending = matches.filter((match) => match.status === "pending" && match.homeTeamId && match.awayTeamId);
  const nextMatch = [...pending].sort(compareSchedule)[0] ?? null;
  const upcomingOverall = [...data.matches.filter((match) => match.status === "pending" && match.homeTeamId && match.awayTeamId)].sort(compareSchedule)[0] ?? null;
  const recent = [...finished].sort((a, b) => compareSchedule(b, a)).slice(0, 5);
  const completion = matches.filter((match) => match.status !== "bye").length
    ? Math.round(finished.length / matches.filter((match) => match.status !== "bye").length * 100)
    : 0;
  const next = upcomingOverall ?? nextMatch;
  const allFinished = data.matches.filter((match) => match.status === "finished").length;

  return <div className="public-site">
    <header className="public-header">
      <Link className="public-brand" href="/" aria-label="Juegos Internos, inicio">
        <Image className="public-brand-logo" src="/logo-ue-guaranda.png" width={58} height={46} alt="Escudo de la Unidad Educativa Guaranda" unoptimized />
        <span><strong>Juegos Internos</strong><small>UNIDAD EDUCATIVA GUARANDA</small></span>
      </Link>
      <div className="public-header-right">
        <nav className="public-nav" aria-label="Secciones"><a href="#posiciones">Posiciones</a><a href="#calendario">Calendario</a><Link href="/inscripciones">Inscripciones</Link></nav>
        <span className="public-season">TEMPORADA {data.config.season}</span>
        <InstallAppButton />
        <Link className="public-login-link" href="/gestion">Ingreso docentes</Link>
      </div>
    </header>

    <main className="public-main">
      <section className="event-hero" aria-label="Juegos internos de la Unidad Educativa Guaranda">
        <div className="event-hero-shade" />
        <div className="event-hero-copy">
          <div className="event-kicker"><span className="event-live-dot" /> LA GRAN FIESTA DEPORTIVA DEL COLEGIO</div>
          <h1>Juegos Internos<br /><span>{data.config.season}</span></h1>
          <p>Una comunidad, muchos equipos y una sola pasión: competir juntos por la Unidad Educativa Guaranda.</p>
          <div className="event-registration"><CalendarDays size={16} /><span><strong>Inscripciones del 5 al 9 de octubre</strong> · fútbol y básquet · Edición 2026–2027</span></div>
          <RegistrationCountdown />
          <div className="event-sport-tags">{data.sports.map((item, index) => <span key={item.id}><i className={`event-sport-mark event-sport-mark-${index}`} />{item.name}</span>)}</div>
          <div className="event-actions"><Link className="event-primary-action" href="/inscripciones">Solicitar inscripción <ArrowRight size={16} /></Link><a className="event-secondary-action" href="#calendario">Próximos partidos <ArrowRight size={16} /></a><a className="event-download-action" href="/afiche-juegos-internos-2026.webp" download="afiche-juegos-internos-2026.webp"><Download size={15} /> Descargar afiche</a></div>
        </div>
        <aside className="event-next-card" aria-label="Siguiente partido">
          <span className="event-next-label"><i /> PRÓXIMO PARTIDO</span>
          {next ? <>
            <small>{next.categoryName} <b>·</b> {next.sportName}</small>
            <div className="event-next-teams"><strong>{next.homeName ?? "Por definir"}</strong><span>VS</span><strong>{next.awayName ?? "Por definir"}</strong></div>
            <div className="event-next-time"><span><CalendarDays size={15} /> {dateLabel(next.matchDate)}</span><b><Clock3 size={15} /> {next.matchTime ? `${next.matchTime} · Ecuador` : "Hora por asignar"}</b></div>
          </> : <><strong className="event-next-empty-title">La competencia está por comenzar</strong><p>Al publicar el calendario, aquí verás el próximo encuentro.</p></>}
          <div className="event-next-foot"><span>{data.teams.length} equipos</span><span>{allFinished} resultados</span></div>
        </aside>
        <div className="event-bottom-line"><span>ESPÍRITU DE EQUIPO</span><i /><span>ORGULLO GUARANDEÑO</span><i /><span>DEPORTES {data.sports.length}</span></div>
      </section>

      <div id="marcadores" className="public-heading-row">
        <div>
          <span className="public-eyebrow">EN DIRECTO · {data.config.tournamentName} {data.config.season}</span>
          <h2>El campeonato, al día</h2>
          <p>Marcadores, posiciones y horarios de los paralelos participantes.</p>
        </div>
        <span className="public-live"><i /> Actualizado por el equipo deportivo</span>
      </div>

      {data.unavailable ? <div className="public-system-message" role="status">Los datos están cargando. Actualiza esta página en unos minutos.</div> : null}

      <div id="posiciones" className="public-filter-row">
        <label>Curso
          <select value={category?.id ?? ""} onChange={(event) => setCategoryId(event.target.value)} disabled={!data.categories.length}>
            {data.categories.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
          </select>
        </label>
        <label>Deporte
          <select value={sport?.id ?? ""} onChange={(event) => setSportId(event.target.value)} disabled={!data.sports.length}>
            {data.sports.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
          </select>
        </label>
      </div>

      <section className="public-stat-grid" aria-label="Resumen de resultados">
        <div className="public-stat"><span className="public-stat-icon public-green"><UsersRound size={20} /></span><div><span>Equipos</span><strong>{teams.length}</strong></div></div>
        <div className="public-stat"><span className="public-stat-icon public-blue"><CheckIcon /></span><div><span>Partidos jugados</span><strong>{finished.length}</strong></div></div>
        <div className="public-stat"><span className="public-stat-icon public-gold"><Clock3 size={20} /></span><div><span>Por jugar</span><strong>{pending.length}</strong></div></div>
        <div className="public-stat"><span className="public-stat-icon public-purple"><Activity size={20} /></span><div><span>Avance</span><strong>{completion}%</strong></div></div>
      </section>

      <div className="public-content-grid">
        <section className="public-card public-standings-card">
          <div className="public-section-title"><div><span className="public-eyebrow">{category?.name ?? "Curso"} · {sport?.name ?? "Deporte"}</span><h2>Tabla de posiciones</h2></div><span className="public-count">{standings.length} equipos</span></div>
          {standings.length ? <div className="public-table-wrap"><table className="public-table">
            <thead><tr><th>#</th><th>Equipo</th><th>PJ</th><th>PG</th><th>PE</th><th>PP</th><th>DG</th><th>PTS</th></tr></thead>
            <tbody>{standings.map((row, index) => <tr key={row.id}>
              <td><span className={`public-rank ${index === 0 && row.played > 0 ? "public-rank-first" : ""}`}>{String(index + 1).padStart(2, "0")}</span></td>
              <td><span className="public-team-cell"><i style={{ backgroundColor: row.jerseyColor ?? "#286f50" }} />{row.name}</span></td>
              <td>{row.played}</td><td>{row.wins}</td><td>{row.draws}</td><td>{row.losses}</td>
              <td className={row.difference > 0 ? "public-positive" : row.difference < 0 ? "public-negative" : ""}>{row.difference > 0 ? `+${row.difference}` : row.difference}</td>
              <td><strong className="public-points">{row.points}</strong></td>
            </tr>)}</tbody>
          </table></div> : <div className="public-empty"><span className="public-empty-mark"><UsersRound size={23} /></span><strong>Aún no hay equipos inscritos</strong><p>La tabla se llenará al registrar paralelos en este deporte.</p></div>}
          <div className="public-table-key"><span>PJ jugados</span><span>PG ganados</span><span>PE empatados</span><span>PP perdidos</span><span>DG diferencia de goles o puntos</span><span>PTS puntos</span></div>
        </section>

        <div className="public-side-column">
          <section className="public-card public-recent-card">
            <div className="public-section-title"><div><span className="public-eyebrow">{category?.name ?? "Curso"} · {sport?.name ?? "Deporte"}</span><h2>Últimos resultados</h2></div><Trophy size={19} className="public-title-icon" /></div>
            {recent.length ? <div className="public-result-list">{recent.map((match) => <article key={match.id} className="public-result-row">
              <div className="public-result-meta"><span>{match.roundLabel}</span><time>{dateLabel(match.matchDate, "short")}</time></div>
              <div className="public-score-line"><strong>{match.homeName}</strong><b>{match.scoreHome}<span>–</span>{match.scoreAway}</b><strong>{match.awayName}</strong></div>
            </article>)}</div> : <div className="public-compact-empty">Los resultados aparecerán aquí después de cada partido.</div>}
          </section>

          <section id="calendario" className="public-card public-calendar-card">
            <div className="public-section-title"><div><span className="public-eyebrow">PRÓXIMOS ENCUENTROS</span><h2>Calendario</h2></div><Clock3 size={19} className="public-title-icon" /></div>
            {pending.length ? <div className="public-schedule-list">{[...pending].sort(compareSchedule).slice(0, 4).map((match) => <article key={match.id} className="public-schedule-row">
              <div className="public-schedule-date"><strong>{match.matchDate ? match.matchDate.slice(8, 10) : "—"}</strong><span>{match.matchDate ? dateLabel(match.matchDate, "short").split(" ").at(-1) : "fecha"}</span></div>
              <div className="public-schedule-copy"><strong>{match.homeName} <span>vs</span> {match.awayName}</strong><small>{match.roundLabel} · {match.venue || "Lugar por asignar"}</small></div>
              <span className="public-schedule-time">{match.matchTime ?? "Por asignar"}</span>
            </article>)}</div> : <div className="public-compact-empty">No hay partidos pendientes para este filtro.</div>}
          </section>
        </div>
      </div>

      <section className="public-sport-strip">
        <div><span className="public-eyebrow">DISCIPLINAS</span><strong>Campeonato por deporte</strong></div>
        {data.sports.map((item, index) => <button className={sport?.id === item.id ? "public-sport-active" : ""} key={item.id} onClick={() => setSportId(item.id)}>
          {index === 0 ? <Flag size={17} /> : index === 1 ? <Activity size={17} /> : <Volleyball size={17} />}{item.name}
        </button>)}
      </section>
    </main>

    <footer className="public-footer"><strong>{data.config.schoolName}</strong><span>Área responsable: {data.config.areaResponsible} · Rector: {data.config.rector}</span><Link href="/gestion">Ingreso para docentes</Link><small>© 2026–2027 · Todos los derechos reservados a Paola Fernanda Prado Vega</small></footer>
  </div>;
}

function CheckIcon() {
  return <Trophy size={20} />;
}
