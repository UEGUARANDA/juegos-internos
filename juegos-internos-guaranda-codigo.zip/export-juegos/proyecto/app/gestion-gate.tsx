"use client";

import { useEffect, useState } from "react";
import AuthPortal from "./auth-portal";
import TorneoApp from "./torneo-app";

type SessionUser = {
  displayName: string;
  email: string;
  username: string;
  mustChangePassword?: boolean;
};

export default function GestionGate() {
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<SessionUser | null>(null);
  const [initialError, setInitialError] = useState("");

  useEffect(() => {
    let active = true;
    fetch("/api/data", { cache: "no-store" })
      .then(async (response) => {
        const payload = await response.json() as { user?: SessionUser; error?: string };
        if (!active) return;
        if (response.ok && payload.user) setUser(payload.user);
        else if (response.status >= 500) setInitialError(payload.error || "No se pudo iniciar el panel. Intenta de nuevo.");
      })
      .catch(() => {
        if (active) setInitialError("No se pudo conectar con el sistema. Revisa tu conexión e inténtalo de nuevo.");
      })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  if (loading) return <main className="auth-page"><section className="auth-card"><div className="auth-card-body">Abriendo el sistema…</div></section></main>;
  if (!user || user.mustChangePassword) return <AuthPortal displayName={user?.displayName} forcePasswordChange={Boolean(user?.mustChangePassword)} initialError={initialError} />;
  return <TorneoApp user={user} signOutHref="/api/auth/logout" />;
}
