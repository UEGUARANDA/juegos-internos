import { env } from "cloudflare:workers";
import PublicResults, { type PublicTournamentData } from "./public-results";
import { seedTournamentDefaults } from "../lib/seed";

export const dynamic = "force-dynamic";

const emptyData: PublicTournamentData = {
  config: {
    tournamentName: "Juegos Internos",
    season: "2026–2027",
    schoolName: "Unidad Educativa Guaranda",
    areaResponsible: "Licenciada Paola Prado",
    rector: "Fernando Villares",
  },
  sports: [],
  categories: [],
  teams: [],
  matches: [],
  unavailable: false,
};

export default async function Home() {
  if (!env.DB) return <PublicResults data={{ ...emptyData, unavailable: true }} />;

  let data: PublicTournamentData = { ...emptyData, sports: [], categories: [], teams: [], matches: [] };
  try {
    const db = env.DB;
    await seedTournamentDefaults(db);
    const [config, sports, categories, teams, matches] = await Promise.all([
      db.prepare(`SELECT tournament_name AS tournamentName, season, school_name AS schoolName,
        area_responsible AS areaResponsible, rector FROM tournament_config WHERE id = 1`)
        .first<PublicTournamentData["config"]>(),
      db.prepare(`SELECT id, name, active, win_points AS winPoints, draw_points AS drawPoints,
        loss_points AS lossPoints, allow_draw AS allowDraw, sort_order AS sortOrder FROM sports
        WHERE active = 1 ORDER BY sort_order, name`).all<PublicTournamentData["sports"][number]>(),
      db.prepare(`SELECT id, name, sort_order AS sortOrder FROM categories WHERE active = 1
        ORDER BY sort_order, name`).all<PublicTournamentData["categories"][number]>(),
      db.prepare(`SELECT id, category_id AS categoryId, sport_id AS sportId, parallel, name,
        jersey_color AS jerseyColor FROM teams ORDER BY category_id, sport_id, parallel`)
        .all<PublicTournamentData["teams"][number]>(),
      db.prepare(`SELECT m.id, m.category_id AS categoryId, m.sport_id AS sportId, m.phase,
        m.round_no AS roundNo, m.round_label AS roundLabel, m.home_team_id AS homeTeamId,
        m.away_team_id AS awayTeamId, ht.name AS homeName, at.name AS awayName,
        ht.jersey_color AS homeColor, at.jersey_color AS awayColor,
        m.match_date AS matchDate, m.match_time AS matchTime, m.venue, m.status,
        m.score_home AS scoreHome, m.score_away AS scoreAway,
        c.name AS categoryName, s.name AS sportName
        FROM matches m LEFT JOIN teams ht ON ht.id = m.home_team_id
        LEFT JOIN teams at ON at.id = m.away_team_id
        LEFT JOIN categories c ON c.id = m.category_id
        LEFT JOIN sports s ON s.id = m.sport_id
        WHERE m.status != 'bye'
        ORDER BY m.match_date, m.match_time, m.category_id, m.sport_id, m.round_no`)
        .all<PublicTournamentData["matches"][number]>(),
    ]);
    data = {
      config: config ?? emptyData.config,
      sports: sports.results ?? [],
      categories: categories.results ?? [],
      teams: teams.results ?? [],
      matches: matches.results ?? [],
      unavailable: false,
    };
  } catch {
    data = { ...emptyData, unavailable: true };
  }
  return <PublicResults data={data} />;
}
