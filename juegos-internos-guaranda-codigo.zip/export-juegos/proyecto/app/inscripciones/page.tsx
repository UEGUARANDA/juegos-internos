import { env } from "cloudflare:workers";
import Image from "next/image";
import Link from "next/link";
import { seedTournamentDefaults } from "../../lib/seed";
import RegistrationForm, { type RegistrationOptions } from "./registration-form";
import InstallAppButton from "../pwa-install";

export const dynamic = "force-dynamic";

function guayaquilToday() {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Guayaquil", year: "numeric", month: "2-digit", day: "2-digit",
  }).formatToParts(new Date());
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}

export default async function InscripcionesPage() {
  let options: RegistrationOptions = { categories: [], sports: [], unavailable: false };
  try {
    if (!env.DB) throw new Error("database unavailable");
    await seedTournamentDefaults(env.DB);
    const [categories, sports] = await Promise.all([
      env.DB.prepare("SELECT id, name FROM categories WHERE active = 1 ORDER BY sort_order, name").all<{ id: string; name: string }>(),
      env.DB.prepare("SELECT id, name FROM sports WHERE active = 1 AND id IN ('futbol','basquet') ORDER BY sort_order, name").all<{ id: string; name: string }>(),
    ]);
    options = { categories: categories.results ?? [], sports: sports.results ?? [], unavailable: false };
  } catch {
    options = { categories: [], sports: [], unavailable: true };
  }
  const today = guayaquilToday();
  return <main className="registration-page">
    <header className="registration-header">
      <Link className="registration-brand" href="/">
        <Image src="/logo-ue-guaranda.png" width={52} height={46} alt="Escudo de la Unidad Educativa Guaranda" unoptimized />
        <span><strong>Juegos Internos</strong><small>UNIDAD EDUCATIVA GUARANDA</small></span>
      </Link>
      <div className="registration-header-actions"><InstallAppButton /><Link href="/">Volver al campeonato</Link></div>
    </header>
    <section className="registration-hero">
      <div className="registration-hero-copy">
        <span className="registration-eyebrow"><i /> EDICIÓN 2026–2027 · INSCRIPCIONES OFICIALES</span>
        <h1>Tu paralelo,<br /><span>en la cancha.</span></h1>
        <p>Completa una solicitud por cada deporte. El equipo organizador revisará la nómina y el comprobante antes de confirmar el cupo.</p>
        <div className="registration-dates"><span className="registration-date-icon">05</span><span><strong>Del 5 al 9 de octubre de 2026</strong><small>Fútbol y básquet · Básica y Bachillerato</small></span></div>
        <div className="registration-trust"><span>01 <b>Completa los datos del equipo</b></span><span>02 <b>Adjunta el comprobante</b></span><span>03 <b>Espera aprobación del Master</b></span></div>
      </div>
      <div className="registration-hero-art" aria-hidden="true"><div className="registration-orbit registration-orbit-a" /><div className="registration-orbit registration-orbit-b" /><span className="registration-ball registration-ball-football" /><span className="registration-ball registration-ball-basket" /><div className="registration-emblem"><Image src="/logo-ue-guaranda.png" width={195} height={150} alt="" unoptimized /></div><span className="registration-art-caption">ORGULLO GUARANDEÑO</span></div>
    </section>
    <div className="registration-content">
      <section className="registration-form-card">
        <div className="registration-section-heading"><div><span>FORMULARIO DE PARTICIPACIÓN</span><h2>Inscribir un equipo</h2></div><b>1 equipo · 1 deporte</b></div>
        {options.unavailable ? <div className="registration-alert" role="status">El formulario está cargando. Vuelve a intentarlo en unos minutos.</div>
          : <RegistrationForm options={options} isOpen={today >= "2026-10-05" && today <= "2026-10-09"} />}
      </section>
      <aside className="registration-aside">
        <div className="registration-aside-card"><span className="registration-aside-symbol">✓</span><span>REVISIÓN SEGURA</span><h3>El equipo no se carga hasta que lo apruebe el Master.</h3><p>La solicitud y el comprobante se guardan de forma privada. Solo el usuario Master podrá revisarlos.</p></div>
        <div className="registration-aside-card registration-payment-card"><span>COMPROBANTE DE PAGO</span><h3>Adjunta un archivo claro y legible.</h3><p>Se acepta PDF, JPG o PNG de hasta 4 MB. Ingresa el valor que pagaste; el sistema no fija un monto.</p><div className="registration-payment-types"><span>PDF</span><span>JPG</span><span>PNG</span></div></div>
        <a className="registration-poster-card" href="/afiche-juegos-internos-2026.webp" download="juegos-internos-guaranda-2026-2027.webp"><Image src="/afiche-juegos-internos-2026.webp" width={420} height={525} alt="Afiche de los Juegos Internos 2026–2027: fútbol y básquet, inscripciones del 5 al 9 de octubre" unoptimized /><span>Descargar afiche oficial <b>↓</b></span></a>
        <p className="registration-privacy-note">La nómina y el teléfono de contacto se usan únicamente para organizar el campeonato. No se publican en la tabla de resultados.</p>
      </aside>
    </div>
    <footer className="registration-footer"><span>© 2026–2027 · Todos los derechos reservados a Paola Fernanda Prado Vega</span><span>Unidad Educativa Guaranda · Área responsable: Lic. Paola Prado</span></footer>
  </main>;
}
