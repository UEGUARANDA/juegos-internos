"use client";

import { CheckCircle2, FileUp, LoaderCircle, LockKeyhole, ShieldCheck, UploadCloud } from "lucide-react";
import { useRef, useState, type FormEvent } from "react";

export type RegistrationOptions = {
  categories: Array<{ id: string; name: string }>;
  sports: Array<{ id: string; name: string }>;
  unavailable: boolean;
};

export default function RegistrationForm({ options, isOpen }: { options: RegistrationOptions; isOpen: boolean }) {
  const [sending, setSending] = useState(false);
  const [fileName, setFileName] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    if (!isOpen) return;
    setSending(true);
    try {
      const response = await fetch("/api/inscripciones", { method: "POST", body: new FormData(event.currentTarget) });
      const result = await response.json() as { error?: string; message?: string };
      if (!response.ok) throw new Error(result.error || "No se pudo enviar la inscripción.");
      setSuccess(true);
      formRef.current?.reset();
      setFileName("");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "No se pudo enviar la inscripción. Revisa tu conexión e inténtalo otra vez.");
    } finally { setSending(false); }
  }

  if (success) return <div className="registration-success" role="status">
    <span><CheckCircle2 size={32} /></span><h3>Solicitud recibida</h3>
    <p>El Master revisará el curso, la nómina y el comprobante. El equipo se cargará automáticamente en el campeonato cuando sea aprobado.</p>
    <button type="button" onClick={() => setSuccess(false)}>Enviar otra inscripción</button>
  </div>;

  return <form ref={formRef} className="registration-form" onSubmit={submit}>
    {!isOpen ? <div className="registration-window-notice"><span className="registration-window-mark"><LockKeyhole size={18} /></span><span><strong>El formulario abre el 5 de octubre</strong><small>Podrás enviar tu solicitud del 5 al 9 de octubre de 2026. La revisión y aprobación se realizará desde Gestión.</small></span></div> : null}
    {error ? <div className="registration-error" role="alert">{error}</div> : null}
    <fieldset disabled={!isOpen || sending}>
      <div className="registration-fields registration-fields-team">
        <label>Curso<select name="categoryId" required defaultValue=""><option value="" disabled>Selecciona el curso</option>{options.categories.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
        <label>Deporte<select name="sportId" required defaultValue=""><option value="" disabled>Selecciona</option>{options.sports.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
        <label>Paralelo<input name="parallel" required maxLength={12} placeholder="Ej.: A" autoCapitalize="characters" /></label>
        <label>Docente responsable<input name="teacherName" required maxLength={100} autoComplete="name" placeholder="Nombre y apellido" /></label>
        <label>Capitán o capitana<input name="captain" required maxLength={100} placeholder="Debe estar en la nómina" /></label>
        <label>Teléfono de contacto<input name="contactPhone" required type="tel" inputMode="tel" autoComplete="tel" maxLength={24} placeholder="Ej.: 099 123 4567" /></label>
        <label className="registration-field-wide">Correo de contacto <span>(opcional)</span><input name="contactEmail" type="email" autoComplete="email" maxLength={160} placeholder="docente@correo.com" /></label>
        <label className="registration-field-wide">Nómina de participantes<textarea name="roster" required rows={5} maxLength={5000} placeholder={"Escribe un participante por línea, incluyendo al capitán o capitana."} /></label>
      </div>
      <div className="registration-form-divider"><span>DATOS DEL PAGO</span><small>El valor se ingresa como fue cancelado; consulta el monto con el área responsable.</small></div>
      <div className="registration-fields registration-fields-payment">
        <label>Nombre de quien realizó el pago<input name="payerName" required maxLength={100} placeholder="Nombre y apellido" /></label>
        <label>Valor pagado (USD)<input name="amountPaid" required type="number" min="0.01" max="99999" step="0.01" placeholder="0,00" /></label>
        <label>Forma de pago<select name="paymentMethod" required defaultValue=""><option value="" disabled>Selecciona</option><option value="transferencia">Transferencia</option><option value="depósito">Depósito</option></select></label>
        <label>Fecha del pago<input name="paymentDate" required type="date" max="2026-10-09" /></label>
        <label className="registration-field-wide">Número de comprobante o referencia <span>(si aparece)</span><input name="paymentReference" maxLength={60} placeholder="Número de transacción" /></label>
        <label className="registration-upload registration-field-wide"><span>Comprobante de pago <b>Obligatorio</b></span><span className="registration-dropzone"><FileUp size={22} /><strong>{fileName || "Toca para adjuntar el comprobante"}</strong><small>PDF, JPG o PNG · máximo 4 MB</small></span><input name="proof" required type="file" accept="application/pdf,image/jpeg,image/png,.pdf,.jpg,.jpeg,.png" onChange={(event) => setFileName(event.currentTarget.files?.[0]?.name ?? "")} /></label>
      </div>
      <label className="registration-consent"><input name="authorization" type="checkbox" required /><span>Confirmo que soy responsable del equipo y cuento con autorización para entregar la nómina al comité organizador con el fin de coordinar el campeonato.</span></label>
      <label className="registration-trap" aria-hidden="true">Sitio web<input name="website" tabIndex={-1} autoComplete="off" /></label>
      <button className="registration-submit" type="submit" disabled={sending || !isOpen}>{sending ? <><LoaderCircle className="registration-spin" size={18} /> Enviando solicitud…</> : <><UploadCloud size={18} /> Enviar solicitud para revisión</>}</button>
      <p className="registration-submit-note"><ShieldCheck size={14} /> El comprobante se mantiene privado. Solo el Master tiene acceso.</p>
    </fieldset>
  </form>;
}
