"use client";

import { Download, Share2, Smartphone, X } from "lucide-react";
import { useEffect, useState } from "react";

type InstallPrompt = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: "accepted" | "dismissed" }> };

export default function InstallAppButton() {
  const [prompt, setPrompt] = useState<InstallPrompt | null>(null);
  const [platform, setPlatform] = useState<"ios" | "android" | "other">("other");
  const [installed, setInstalled] = useState(false);
  const [showHelp, setShowHelp] = useState(false);

  // Device and installed state are only available in the browser; seed them after hydration.
  useEffect(() => {
    const agent = navigator.userAgent;
    const apple = /iPhone|iPad|iPod/.test(agent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
    const android = /Android/i.test(agent);
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setPlatform(apple ? "ios" : android ? "android" : "other");
    const installedNow = window.matchMedia("(display-mode: standalone)").matches || Boolean((navigator as Navigator & { standalone?: boolean }).standalone);
    setInstalled(installedNow);
    const handler = (event: Event) => { event.preventDefault(); setPrompt(event as InstallPrompt); };
    const installedHandler = () => { setInstalled(true); setShowHelp(false); };
    window.addEventListener("beforeinstallprompt", handler);
    window.addEventListener("appinstalled", installedHandler);
    if ("serviceWorker" in navigator) void navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    return () => {
      window.removeEventListener("beforeinstallprompt", handler);
      window.removeEventListener("appinstalled", installedHandler);
    };
  }, []);

  async function install() {
    if (prompt) {
      await prompt.prompt();
      const result = await prompt.userChoice;
      if (result.outcome === "accepted") setInstalled(true);
      setPrompt(null);
      return;
    }
    setShowHelp(true);
  }

  return <>
    <button className="install-app-button" type="button" onClick={() => void install()} aria-haspopup="dialog">
      {installed ? <Smartphone size={16} /> : <Download size={16} />}
      {installed ? "App instalada" : "Instalar en el teléfono"}
    </button>
    {showHelp ? <div className="install-help-backdrop" role="presentation" onClick={() => setShowHelp(false)}>
      <section className="install-help-dialog" role="dialog" aria-modal="true" aria-labelledby="install-help-title" onClick={(event) => event.stopPropagation()}>
        <button className="install-help-close" type="button" aria-label="Cerrar" onClick={() => setShowHelp(false)}><X size={18} /></button>
        <span className="install-help-icon"><Smartphone size={25} /></span><p className="install-help-kicker">ACCESO RÁPIDO EN TU CELULAR</p><h2 id="install-help-title">Añade los Juegos Internos a tu pantalla</h2>
        {platform === "ios" ? <p>En <strong>Safari</strong>, toca <Share2 size={15} /> <strong>Compartir</strong> y elige <strong>Añadir a pantalla de inicio</strong>.</p>
          : <p>Abre el menú del navegador <strong>⋮</strong> y toca <strong>Instalar aplicación</strong> o <strong>Añadir a pantalla de inicio</strong>.</p>}
        <small>El acceso conserva la página oficial del campeonato. Los resultados y las inscripciones requieren conexión a internet.</small>
      </section>
    </div> : null}
  </>;
}
