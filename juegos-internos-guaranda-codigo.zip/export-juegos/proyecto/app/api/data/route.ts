import { env } from "cloudflare:workers";
import { seedTournamentDefaults } from "../../../lib/seed";
import { calculateStandings } from "../../../lib/standings";
import {
  createTemporaryPassword,
  ensureLocalAuthSchema,
  getSessionUserFromCookieHeader,
  hashPassword,
  newPasswordSalt,
  normalizeUsername,
} from "../../local-auth";

type JsonObject = Record<string, unknown>;
type Db = D1Database;

class HttpError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

function json(data: unknown, status = 200) {
  return Response.json(data, {
    status,
    headers: { "Cache-Control": "private, no-store" },
  });
}

function getDatabase(): Db {
  if (!env.DB) throw new HttpError("La base de datos está iniciando. Intenta de nuevo en unos minutos.", 503);
  return env.DB;
}

async function runBatch(db: Db, statements: D1PreparedStatement[]) {
  for (let start = 0; start < statements.length; start += 80) {
    await db.batch(statements.slice(start, start + 80));
  }
}

function cleanText(value: unknown, limit = 120) {
  return typeof value === "string" ? value.trim().slice(0, limit) : "";
}

function safeInteger(value: unknown, label: string, min = 0, max = 999) {
  const number = Number(value);
  if (!Number.isInteger(number) || number < min || number > max) {
    throw new HttpError(`${label}: ingresa un número entre ${min} y ${max}.`);
  }
  return number;
}

function validDate(value: unknown) {
  const date = cleanText(value, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new HttpError("Selecciona una fecha válida.");
  return date;
}

function validTime(value: unknown) {
  const time = cleanText(value, 5);
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) throw new HttpError("Selecciona una hora válida.");
  return time;
}

function assertSameOrigin(request: Request) {
  const origin = request.headers.get("origin");
  if (origin && new URL(origin).origin !== new URL(request.url).origin) {
    throw new HttpError("La solicitud no pudo validarse. Recarga la página e inténtalo de nuevo.", 403);
  }
}

async function requireUser(request: Request, db: Db) {
  const user = await getSessionUserFromCookieHeader(db, request.headers.get("cookie"));
  if (!user) throw new HttpError("Ingresa con tu usuario y contraseña para usar el sistema.", 401);
  if (user.mustChangePassword) throw new HttpError("Cambia tu contraseña temporal antes de continuar.", 403);
  return { ...user, userId: user.email };
}

async function authorizeStaff(db: Db, user: { displayName: string; email: string; username: string; mustChangePassword: boolean }) {
  const email = user.email.trim().toLowerCase();
  const record = await db.prepare(`SELECT display_name AS displayName, role, active FROM app_users WHERE email = ?`)
    .bind(email).first<{ displayName: string; role: "master" | "docente"; active: number }>();
  if (!record || Number(record.active) !== 1) {
    throw new HttpError("Tu cuenta está desactivada. Comunícate con la persona Master.", 403);
  }
  return { ...user, displayName: record.displayName || user.displayName, email, role: record.role };
}

async function loadState(db: Db, user: { displayName: string; email: string; username: string; mustChangePassword: boolean; role: "master" | "docente" }) {
  await seedTournamentDefaults(db);
  const [config, sportRows, categoryRows, teamRows, matchRows, auditRows, staffRows, registrationRows] = await Promise.all([
    db.prepare("SELECT id, tournament_name AS tournamentName, season, school_name AS schoolName, area_responsible AS areaResponsible, rector, updated_at AS updatedAt FROM tournament_config WHERE id = 1").first<JsonObject>(),
    db.prepare("SELECT id, name, active, win_points AS winPoints, draw_points AS drawPoints, loss_points AS lossPoints, allow_draw AS allowDraw, sort_order AS sortOrder FROM sports ORDER BY sort_order, name").all<JsonObject>(),
    db.prepare("SELECT id, name, sort_order AS sortOrder, active FROM categories ORDER BY sort_order, name").all<JsonObject>(),
    db.prepare("SELECT id, category_id AS categoryId, sport_id AS sportId, parallel, name, captain, teacher, jersey_color AS jerseyColor, roster_json AS rosterJson, created_at AS createdAt FROM teams ORDER BY category_id, sport_id, parallel").all<JsonObject>(),
    db.prepare(`SELECT m.id, m.draw_id AS drawId, m.category_id AS categoryId, m.sport_id AS sportId,
      m.phase, m.round_no AS roundNo, m.round_label AS roundLabel,
      m.home_team_id AS homeTeamId, m.away_team_id AS awayTeamId,
      ht.name AS homeName, at.name AS awayName, ht.jersey_color AS homeColor, at.jersey_color AS awayColor,
      m.match_date AS matchDate, m.match_time AS matchTime, m.venue, m.status,
      m.score_home AS scoreHome, m.score_away AS scoreAway, m.detail_json AS detailJson,
      m.winner_override AS winnerOverride, m.notes, c.name AS categoryName, s.name AS sportName
      FROM matches m LEFT JOIN teams ht ON ht.id = m.home_team_id
      LEFT JOIN teams at ON at.id = m.away_team_id
      LEFT JOIN categories c ON c.id = m.category_id
      LEFT JOIN sports s ON s.id = m.sport_id
      ORDER BY CASE m.phase WHEN 'round_robin' THEN 1 WHEN 'semifinal' THEN 2 WHEN 'third_place' THEN 3 ELSE 4 END,
      m.match_date, m.match_time, m.category_id, m.sport_id, m.round_no, m.created_at`).all<JsonObject>(),
    db.prepare("SELECT id, action, match_id AS matchId, actor_email AS actorEmail, created_at AS createdAt FROM audit_log ORDER BY created_at DESC LIMIT 8").all<JsonObject>(),
    user.role === "master"
      ? db.prepare(`SELECT u.email, u.display_name AS displayName, c.username, u.role, u.active,
          u.created_at AS createdAt FROM app_users u LEFT JOIN app_credentials c ON c.email = u.email
          WHERE c.username IS NOT NULL OR u.role = 'master'
          ORDER BY CASE u.role WHEN 'master' THEN 0 ELSE 1 END, u.display_name`).all<JsonObject>()
      : Promise.resolve({ results: [] as JsonObject[] }),
    user.role === "master"
      ? db.prepare("SELECT COUNT(*) AS total FROM registrations WHERE status = 'pending'").first<{ total: number }>()
      : Promise.resolve({ total: 0 }),
  ]);
  return {
    config,
    sports: sportRows.results ?? [],
    categories: categoryRows.results ?? [],
    teams: (teamRows.results ?? []).map((team) => ({
      ...team,
      // Student rosters and staff details are only visible to the Master account.
      ...(user.role === "master" ? {} : { captain: "", teacher: "", rosterJson: "[]", createdAt: undefined }),
      roster: user.role === "master" ? safeRoster(team.rosterJson) : [],
    })),
    matches: (matchRows.results ?? []).map((match) => ({
      ...match,
      detail: safeJson(match.detailJson),
    })),
    recentActivity: user.role === "master" ? auditRows.results ?? [] : [],
    user: { displayName: user.displayName, email: user.email, username: user.username, mustChangePassword: user.mustChangePassword },
    accessRole: user.role,
    staffUsers: staffRows.results ?? [],
    pendingRegistrations: Number(registrationRows?.total ?? 0),
  };
}

function safeJson(value: unknown): JsonObject {
  try {
    const parsed = JSON.parse(typeof value === "string" ? value : "{}");
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch {
    return {};
  }
}

function safeRoster(value: unknown): string[] {
  try {
    const parsed = JSON.parse(typeof value === "string" ? value : "[]");
    return Array.isArray(parsed) ? parsed.filter((name) => typeof name === "string") : [];
  } catch {
    return [];
  }
}

function randomId() {
  return crypto.randomUUID();
}

function shuffle<T>(items: T[]) {
  const result = [...items];
  for (let i = result.length - 1; i > 0; i -= 1) {
    const bytes = new Uint32Array(1);
    crypto.getRandomValues(bytes);
    const j = bytes[0] % (i + 1);
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

function roundRobin(teamIds: string[]) {
  const ring: Array<string | null> = shuffle(teamIds);
  if (ring.length % 2) ring.push(null);
  const fixtures: Array<{ round: number; home: string | null; away: string | null }> = [];
  const roundCount = ring.length - 1;
  let current = [...ring];
  for (let round = 1; round <= roundCount; round += 1) {
    for (let i = 0; i < current.length / 2; i += 1) {
      let home = current[i];
      let away = current[current.length - 1 - i];
      if (home && away && round % 2 === 0) [home, away] = [away, home];
      fixtures.push({ round, home, away });
    }
    current = [current[0], current[current.length - 1], ...current.slice(1, -1)];
  }
  return fixtures;
}

function canonicalId(value: string) {
  const base = value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40);
  return base || randomId();
}

function toDateWithOffset(date: string, offsetDays: number) {
  const result = new Date(`${date}T12:00:00Z`);
  result.setUTCDate(result.getUTCDate() + offsetDays);
  return result.toISOString().slice(0, 10);
}

async function createNextPhase(db: Db, categoryId: string, sportId: string) {
  const teamRows = await db.prepare("SELECT id, name, parallel, jersey_color AS jerseyColor FROM teams WHERE category_id = ? AND sport_id = ? ORDER BY parallel").bind(categoryId, sportId).all<JsonObject>();
  const teams = (teamRows.results ?? []) as Array<{ id: string; name: string; parallel: string; jerseyColor: string }>;
  if (teams.length < 2) throw new HttpError("Inscribe por lo menos dos equipos antes de avanzar.");

  const matchRows = await db.prepare(`SELECT category_id AS categoryId, sport_id AS sportId, phase, status,
    home_team_id AS homeTeamId, away_team_id AS awayTeamId,
    score_home AS scoreHome, score_away AS scoreAway, winner_override AS winnerOverride
    FROM matches WHERE category_id = ? AND sport_id = ? ORDER BY round_no, created_at`).bind(categoryId, sportId).all<JsonObject>();
  const matches = (matchRows.results ?? []) as Array<{
    categoryId: string; sportId: string; phase: string; status: string;
    homeTeamId: string | null; awayTeamId: string | null;
    scoreHome: number | null; scoreAway: number | null; winnerOverride: string | null;
  }>;
  if (!matches.length) throw new HttpError("Primero realiza el sorteo de esta categoría y deporte.");
  if (matches.some((match) => match.phase === "final" && match.status === "finished")) {
    throw new HttpError("El campeonato de esta categoría ya tiene una final registrada.");
  }

  const semis = matches.filter((match) => match.phase === "semifinal");
  if (semis.length) {
    if (semis.some((match) => match.status !== "finished")) {
      throw new HttpError("Registra las dos semifinales antes de crear la final.");
    }
    if (matches.some((match) => match.phase === "final")) {
      throw new HttpError("La final ya está creada.");
    }
    const winnerOf = (match: (typeof semis)[number]) => {
      if (match.winnerOverride) return match.winnerOverride;
      if (match.scoreHome === null || match.scoreAway === null || match.scoreHome === match.scoreAway) return null;
      return match.scoreHome > match.scoreAway ? match.homeTeamId : match.awayTeamId;
    };
    const winners = semis.map(winnerOf);
    if (winners.some((id) => !id)) throw new HttpError("Confirma el ganador de cada semifinal antes de continuar.");
    const losers = semis.map((match, index) => match.homeTeamId === winners[index] ? match.awayTeamId : match.homeTeamId);
    const statements = [
      db.prepare(`INSERT INTO matches (id, category_id, sport_id, phase, round_no, round_label,
        home_team_id, away_team_id, status, venue, detail_json)
        VALUES (?, ?, ?, 'final', 1, 'Final', ?, ?, 'pending', 'Por asignar', '{}')`)
        .bind(randomId(), categoryId, sportId, winners[0], winners[1]),
      db.prepare(`INSERT INTO matches (id, category_id, sport_id, phase, round_no, round_label,
        home_team_id, away_team_id, status, venue, detail_json)
        VALUES (?, ?, ?, 'third_place', 1, 'Tercer puesto', ?, ?, 'pending', 'Por asignar', '{}')`)
        .bind(randomId(), categoryId, sportId, losers[0], losers[1]),
    ];
    await db.batch(statements);
    return "Se crearon la final y el partido por el tercer puesto.";
  }

  const league = matches.filter((match) => match.phase === "round_robin" && match.status !== "bye");
  if (!league.length || league.some((match) => match.status !== "finished")) {
    throw new HttpError("Termina todos los partidos de la primera fase antes de avanzar.");
  }
  if (matches.some((match) => match.phase === "final")) throw new HttpError("La final ya está creada.");

  const sport = await db.prepare("SELECT id, win_points AS winPoints, draw_points AS drawPoints, loss_points AS lossPoints, allow_draw AS allowDraw FROM sports WHERE id = ?").bind(sportId).first<{
    id: string; winPoints: number; drawPoints: number; lossPoints: number; allowDraw: number;
  }>();
  if (!sport) throw new HttpError("No se encontró el deporte seleccionado.", 404);
  const table = calculateStandings(teams, matches, sport);
  if (teams.length >= 4) {
    const statements = [
      db.prepare(`INSERT INTO matches (id, category_id, sport_id, phase, round_no, round_label,
        home_team_id, away_team_id, status, venue, detail_json)
        VALUES (?, ?, ?, 'semifinal', 1, ?, ?, ?, 'pending', 'Por asignar', '{}')`)
        .bind(randomId(), categoryId, sportId, "Semifinal 1 · 1.º vs 4.º", table[0].id, table[3].id),
      db.prepare(`INSERT INTO matches (id, category_id, sport_id, phase, round_no, round_label,
        home_team_id, away_team_id, status, venue, detail_json)
        VALUES (?, ?, ?, 'semifinal', 1, ?, ?, ?, 'pending', 'Por asignar', '{}')`)
        .bind(randomId(), categoryId, sportId, "Semifinal 2 · 2.º vs 3.º", table[1].id, table[2].id),
    ];
    await db.batch(statements);
    return "Semifinales generadas automáticamente: 1.º contra 4.º y 2.º contra 3.º.";
  }

  const finalists = table.slice(0, 2);
  await db.prepare(`INSERT INTO matches (id, category_id, sport_id, phase, round_no, round_label,
    home_team_id, away_team_id, status, venue, detail_json)
    VALUES (?, ?, ?, 'final', 1, 'Final', ?, ?, 'pending', 'Por asignar', '{}')`)
    .bind(randomId(), categoryId, sportId, finalists[0].id, finalists[1].id).run();
  return "Final generada entre los dos equipos mejor ubicados.";
}

export async function GET(request: Request) {
  try {
    const db = getDatabase();
    await ensureLocalAuthSchema(db);
    const user = await requireUser(request, db);
    const staffUser = await authorizeStaff(db, user);
    return json(await loadState(db, staffUser));
  } catch (error) {
    const status = error instanceof HttpError ? error.status : 500;
    const message = error instanceof Error ? error.message : "No se pudo cargar la información.";
    return json({ error: message }, status);
  }
}

export async function POST(request: Request) {
  try {
    assertSameOrigin(request);
    const db = getDatabase();
    await ensureLocalAuthSchema(db);
    const user = await requireUser(request, db);
    await seedTournamentDefaults(db);
    const staffUser = await authorizeStaff(db, user);
    const body = (await request.json()) as JsonObject;
    const action = cleanText(body.action, 40);
    let temporaryCredential: { username: string; password: string } | undefined;

    // Deny by default: docentes may only submit or correct a match result.
    // All tournament setup, schedule, roster, draw and account changes stay Master-only.
    if (staffUser.role === "docente" && action !== "save_result") {
      throw new HttpError("Tu acceso docente solo permite registrar o corregir resultados. Esta acción corresponde al usuario Master.", 403);
    }

    if (action === "add_teacher") {
      const displayName = cleanText(body.displayName, 100);
      const username = normalizeUsername(body.username);
      const emailInput = cleanText(body.email, 160).toLowerCase();
      const email = emailInput || `${username.toLowerCase()}@usuarios.ueguaranda.invalid`;
      if (!displayName) throw new HttpError("Escribe el nombre del docente.");
      if (!/^[A-Za-z0-9._-]{3,32}$/.test(username)) throw new HttpError("El usuario debe tener entre 3 y 32 caracteres y usar letras, números, punto, guion o guion bajo.");
      if (emailInput && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailInput)) throw new HttpError("Revisa el correo. También puedes dejarlo vacío.");
      const duplicateUser = await db.prepare("SELECT email FROM app_credentials WHERE username = ? COLLATE NOCASE LIMIT 1").bind(username).first();
      if (duplicateUser) throw new HttpError("Ese nombre de usuario ya existe. Escribe otro.");
      const duplicateEmail = await db.prepare("SELECT email FROM app_users WHERE email = ? LIMIT 1").bind(email).first();
      if (duplicateEmail) throw new HttpError("Ese correo ya tiene una cuenta registrada.");
      const temporaryPassword = createTemporaryPassword();
      const salt = newPasswordSalt();
      const passwordHash = await hashPassword(temporaryPassword, salt);
      await db.batch([
        db.prepare("INSERT INTO app_users (email, display_name, role, active, created_by_email) VALUES (?, ?, 'docente', 1, ?)")
          .bind(email, displayName, staffUser.email),
        db.prepare(`INSERT INTO app_credentials (email, username, password_salt, password_hash, must_change_password)
          VALUES (?, ?, ?, ?, 1)`).bind(email, username, salt, passwordHash),
      ]);
      temporaryCredential = { username, password: temporaryPassword };
    } else if (action === "set_teacher_access") {
      const email = cleanText(body.email, 160).toLowerCase();
      const active = body.active === true ? 1 : 0;
      const result = await db.prepare("UPDATE app_users SET active = ? WHERE email = ? AND role = 'docente'").bind(active, email).run();
      if (!result.meta.changes) throw new HttpError("No se encontró la cuenta docente seleccionada.", 404);
      if (!active) await db.prepare("DELETE FROM app_sessions WHERE email = ?").bind(email).run();
    } else if (action === "reset_teacher_password") {
      const email = cleanText(body.email, 160).toLowerCase();
      const teacher = await db.prepare(`SELECT u.email, u.active, c.username FROM app_users u
        JOIN app_credentials c ON c.email = u.email WHERE u.email = ? AND u.role = 'docente' LIMIT 1`)
        .bind(email).first<{ email: string; active: number; username: string }>();
      if (!teacher) throw new HttpError("No se encontró la cuenta docente.", 404);
      if (Number(teacher.active) !== 1) throw new HttpError("Habilita la cuenta antes de restablecer su contraseña.");
      const temporaryPassword = createTemporaryPassword();
      const salt = newPasswordSalt();
      const passwordHash = await hashPassword(temporaryPassword, salt);
      await db.prepare(`UPDATE app_credentials SET password_salt = ?, password_hash = ?, must_change_password = 1 WHERE email = ?`)
        .bind(salt, passwordHash, email).run();
      await db.prepare("DELETE FROM app_sessions WHERE email = ?").bind(email).run();
      temporaryCredential = { username: teacher.username, password: temporaryPassword };
    } else if (action === "save_settings") {
      const tournamentName = cleanText(body.tournamentName, 100);
      const season = cleanText(body.season, 16);
      const schoolName = cleanText(body.schoolName, 100);
      const areaResponsible = cleanText(body.areaResponsible, 100);
      const rector = cleanText(body.rector, 100);
      if (!tournamentName || !season || !schoolName || !areaResponsible || !rector) {
        throw new HttpError("Completa el nombre del campeonato, año, institución y responsables.");
      }
      await db.prepare(`UPDATE tournament_config SET tournament_name = ?, season = ?, school_name = ?,
        area_responsible = ?, rector = ?, updated_at = CURRENT_TIMESTAMP WHERE id = 1`)
        .bind(tournamentName, season, schoolName, areaResponsible, rector).run();
    } else if (action === "add_category") {
      const name = cleanText(body.name, 60);
      if (!name) throw new HttpError("Escribe el curso o categoría.");
      const duplicate = await db.prepare("SELECT id FROM categories WHERE lower(name) = lower(?) LIMIT 1").bind(name).first();
      if (duplicate) throw new HttpError("Ese curso ya está registrado.");
      const order = safeInteger(body.sortOrder ?? 99, "Orden", 1, 999);
      await db.prepare("INSERT INTO categories (id, name, sort_order, active) VALUES (?, ?, ?, 1)")
        .bind(canonicalId(name) + "-" + randomId().slice(0, 6), name, order).run();
    } else if (action === "remove_category") {
      const id = cleanText(body.id, 80);
      const used = await db.prepare("SELECT id FROM teams WHERE category_id = ? LIMIT 1").bind(id).first();
      if (used) throw new HttpError("Este curso tiene equipos inscritos. Elimina primero sus equipos y partidos.");
      await db.prepare("DELETE FROM categories WHERE id = ?").bind(id).run();
    } else if (action === "save_sport_rules") {
      const sportId = cleanText(body.sportId, 40);
      const winPoints = safeInteger(body.winPoints, "Puntos por ganar", 0, 20);
      const drawPoints = safeInteger(body.drawPoints, "Puntos por empatar", 0, 20);
      const lossPoints = safeInteger(body.lossPoints, "Puntos por perder", 0, 20);
      const allowDraw = body.allowDraw ? 1 : 0;
      const result = await db.prepare("UPDATE sports SET win_points = ?, draw_points = ?, loss_points = ?, allow_draw = ? WHERE id = ?")
        .bind(winPoints, drawPoints, lossPoints, allowDraw, sportId).run();
      if (!result.meta.changes) throw new HttpError("No se encontró el deporte seleccionado.", 404);
    } else if (action === "add_team") {
      const categoryId = cleanText(body.categoryId, 80);
      const sportId = cleanText(body.sportId, 40);
      const parallel = cleanText(body.parallel, 12).toUpperCase();
      if (!/^[A-Z0-9ÁÉÍÓÚÜÑ-]{1,12}$/.test(parallel)) throw new HttpError("Escribe un paralelo válido, por ejemplo A o B.");
      const category = await db.prepare("SELECT name FROM categories WHERE id = ? AND active = 1").bind(categoryId).first<{ name: string }>();
      const sport = await db.prepare("SELECT id FROM sports WHERE id = ? AND active = 1").bind(sportId).first();
      if (!category || !sport) throw new HttpError("Selecciona un curso y un deporte habilitados.");
      const drawn = await db.prepare("SELECT id FROM matches WHERE category_id = ? AND sport_id = ? LIMIT 1").bind(categoryId, sportId).first();
      if (drawn) throw new HttpError("Ya existe un sorteo para este curso y deporte. Registra los equipos antes de sortear.");
      const roster = Array.isArray(body.roster)
        ? [...new Set(body.roster.map((name) => cleanText(name, 80)).filter(Boolean))].slice(0, 40)
        : [];
      const teamId = randomId();
      await db.prepare(`INSERT INTO teams (id, category_id, sport_id, parallel, name, captain, teacher,
        jersey_color, roster_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
        .bind(teamId, categoryId, sportId, parallel, `${category.name} ${parallel}`, cleanText(body.captain, 80),
          cleanText(body.teacher, 100), /^#[0-9A-Fa-f]{6}$/.test(cleanText(body.jerseyColor, 7)) ? body.jerseyColor : "#1c6b51", JSON.stringify(roster)).run();
    } else if (action === "remove_team") {
      const id = cleanText(body.id, 80);
      const used = await db.prepare("SELECT id FROM matches WHERE home_team_id = ? OR away_team_id = ? LIMIT 1").bind(id, id).first();
      if (used) throw new HttpError("El equipo aparece en un sorteo. Reinicia el calendario de ese deporte antes de eliminarlo.");
      await db.prepare("DELETE FROM teams WHERE id = ?").bind(id).run();
    } else if (action === "draw") {
      const categoryId = cleanText(body.categoryId, 80);
      const sportId = cleanText(body.sportId, 40);
      const rows = await db.prepare("SELECT id FROM teams WHERE category_id = ? AND sport_id = ? ORDER BY parallel")
        .bind(categoryId, sportId).all<{ id: string }>();
      const teamIds = (rows.results ?? []).map((row) => row.id);
      if (teamIds.length < 2) throw new HttpError("Inscribe al menos dos paralelos en esta categoría y deporte.");
      const completed = await db.prepare("SELECT id FROM matches WHERE category_id = ? AND sport_id = ? AND status = 'finished' LIMIT 1")
        .bind(categoryId, sportId).first();
      if (completed) throw new HttpError("Ya hay resultados registrados; no se puede cambiar un sorteo con partidos jugados.");
      const drawId = randomId();
      const fixtures = roundRobin(teamIds);
      const statements = [
        db.prepare("DELETE FROM matches WHERE category_id = ? AND sport_id = ?").bind(categoryId, sportId),
        db.prepare("DELETE FROM draws WHERE category_id = ? AND sport_id = ?").bind(categoryId, sportId),
        db.prepare("INSERT INTO draws (id, category_id, sport_id, format, team_count, created_by) VALUES (?, ?, ?, 'round_robin', ?, ?)")
          .bind(drawId, categoryId, sportId, teamIds.length, user.userId),
      ];
      for (const fixture of fixtures) {
        const isBye = !fixture.home || !fixture.away;
        statements.push(db.prepare(`INSERT INTO matches (id, draw_id, category_id, sport_id, phase, round_no,
          round_label, home_team_id, away_team_id, status, venue, detail_json)
          VALUES (?, ?, ?, ?, 'round_robin', ?, ?, ?, ?, ?, 'Por asignar', '{}')`)
          .bind(randomId(), drawId, categoryId, sportId, fixture.round, `Fecha ${fixture.round}`,
            fixture.home ?? fixture.away, fixture.away, isBye ? "bye" : "pending"));
      }
      await runBatch(db, statements);
    } else if (action === "schedule_all") {
      const startDate = validDate(body.startDate);
      const startTime = validTime(body.startTime);
      const matchMinutes = safeInteger(body.matchMinutes ?? 40, "Minutos por partido", 5, 240);
      const breakMinutes = safeInteger(body.breakMinutes ?? 10, "Descanso", 0, 240);
      const matchesPerDay = safeInteger(body.matchesPerDay ?? 10, "Partidos por día", 1, 40);
      const venue = cleanText(body.venue, 100) || "Cancha principal";
      const slot = matchMinutes + breakMinutes;
      const startMinutes = Number(startTime.slice(0, 2)) * 60 + Number(startTime.slice(3, 5));
      if (startMinutes + slot * matchesPerDay > 24 * 60) throw new HttpError("Reduce los partidos por día o el tiempo de cada encuentro para que la jornada no pase de medianoche.");
      const pending = await db.prepare(`SELECT id FROM matches WHERE status = 'pending' AND home_team_id IS NOT NULL
        AND away_team_id IS NOT NULL ORDER BY category_id, sport_id,
        CASE phase WHEN 'round_robin' THEN 1 WHEN 'semifinal' THEN 2 WHEN 'third_place' THEN 3 ELSE 4 END, round_no, created_at`).all<{ id: string }>();
      const statements = (pending.results ?? []).map((match, index) => {
        const day = Math.floor(index / matchesPerDay);
        const slotIndex = index % matchesPerDay;
        const minutes = startMinutes + slotIndex * slot;
        const time = `${String(Math.floor(minutes / 60)).padStart(2, "0")}:${String(minutes % 60).padStart(2, "0")}`;
        return db.prepare("UPDATE matches SET match_date = ?, match_time = ?, venue = ? WHERE id = ?")
          .bind(toDateWithOffset(startDate, day), time, venue, match.id);
      });
      if (statements.length) await runBatch(db, statements);
    } else if (action === "save_result") {
      const matchId = cleanText(body.matchId, 80);
      const match = await db.prepare(`SELECT m.*, s.allow_draw AS allowDraw FROM matches m
        JOIN sports s ON s.id = m.sport_id WHERE m.id = ?`).bind(matchId).first<JsonObject>();
      if (!match || !match.home_team_id || !match.away_team_id || match.status === "bye") {
        throw new HttpError("No se encontró el partido seleccionado.", 404);
      }
      const scoreHome = safeInteger(body.scoreHome, "Marcador local", 0, 999);
      const scoreAway = safeInteger(body.scoreAway, "Marcador visitante", 0, 999);
      const phase = cleanText(match.phase, 40);
      const allowDraw = Number(match.allowDraw) === 1;
      const override = cleanText(body.winnerOverride, 80) || null;
      if (scoreHome === scoreAway && (phase !== "round_robin" || !allowDraw) && !override) {
        throw new HttpError("El marcador debe definir un ganador. Registra el resultado final después del tiempo extra o desempate.");
      }
      if (override && override !== match.home_team_id && override !== match.away_team_id) {
        throw new HttpError("Selecciona como ganador a uno de los equipos del partido.");
      }
      if (scoreHome !== scoreAway && override) throw new HttpError("El desempate solo se usa cuando el marcador termina igualado.");
      if (phase === "round_robin" && override) throw new HttpError("El desempate no se aplica durante la primera fase.");
      const details = body.detail && typeof body.detail === "object" && !Array.isArray(body.detail) ? JSON.stringify(body.detail) : "{}";
      const before = JSON.stringify({ scoreHome: match.score_home, scoreAway: match.score_away, winnerOverride: match.winner_override, status: match.status });
      const after = JSON.stringify({ scoreHome, scoreAway, winnerOverride: override, status: "finished" });
      await runBatch(db, [
        db.prepare(`UPDATE matches SET score_home = ?, score_away = ?, winner_override = ?, detail_json = ?, status = 'finished'
          WHERE id = ?`).bind(scoreHome, scoreAway, override, details, matchId),
        db.prepare(`INSERT INTO audit_log (id, action, match_id, actor_id, actor_email, before_json, after_json)
          VALUES (?, 'resultado_guardado', ?, ?, ?, ?, ?)`).bind(randomId(), matchId, user.userId, user.email, before, after),
      ]);
    } else if (action === "save_schedule") {
      const matchId = cleanText(body.matchId, 80);
      const matchDate = validDate(body.matchDate);
      const matchTime = validTime(body.matchTime);
      const venue = cleanText(body.venue, 100) || "Por asignar";
      const result = await db.prepare("UPDATE matches SET match_date = ?, match_time = ?, venue = ? WHERE id = ? AND status != 'bye'")
        .bind(matchDate, matchTime, venue, matchId).run();
      if (!result.meta.changes) throw new HttpError("No se encontró el partido para programarlo.", 404);
    } else if (action === "advance") {
      const categoryId = cleanText(body.categoryId, 80);
      const sportId = cleanText(body.sportId, 40);
      const message = await createNextPhase(db, categoryId, sportId);
      return json({ ok: true, message, state: await loadState(db, staffUser) });
    } else {
      throw new HttpError("Selecciona una acción válida.");
    }

    return json({ ok: true, state: await loadState(db, staffUser), ...(temporaryCredential ? { temporaryCredential } : {}) });
  } catch (error) {
    const status = error instanceof HttpError ? error.status : 500;
    const message = error instanceof Error ? error.message : "No se pudo guardar la información.";
    return json({ error: message }, status);
  }
}
