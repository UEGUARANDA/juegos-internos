import { env } from "cloudflare:workers";
import { ensureLocalAuthSchema, getSessionUserFromCookieHeader } from "../../local-auth";

const MAX_RECEIPT_BYTES = 4 * 1024 * 1024;
const ALLOWED_TYPES = new Set(["application/pdf", "image/jpeg", "image/png"]);
const OPEN_DATE = "2026-10-05";
const CLOSE_DATE = "2026-10-09";

type RegistrationRow = {
  id: string;
  categoryId: string;
  sportId: string;
  parallel: string;
  teamName: string;
  teacherName: string;
  captain: string;
  contactPhone: string;
  contactEmail: string;
  rosterJson: string;
  payerName: string;
  amountCents: number;
  paymentMethod: string;
  paymentDate: string;
  paymentReference: string;
  proofObjectKey: string;
  proofName: string;
  proofType: string;
  proofSize: number;
  status: string;
  decisionNote: string;
  createdAt: string;
  reviewedBy: string | null;
  reviewedAt: string | null;
  teamId: string | null;
};

function json(data: unknown, status = 200) {
  return Response.json(data, { status, headers: { "Cache-Control": "private, no-store" } });
}

function text(value: FormDataEntryValue | unknown, max = 120) {
  return typeof value === "string" ? value.trim().replace(/[\u0000-\u001f\u007f]/g, "").slice(0, max) : "";
}

function guayaquilToday() {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Guayaquil", year: "numeric", month: "2-digit", day: "2-digit",
  }).formatToParts(new Date());
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}

function requireSameOrigin(request: Request) {
  const origin = request.headers.get("origin");
  if (origin && new URL(origin).origin !== new URL(request.url).origin) {
    throw Object.assign(new Error("No se pudo validar el envío. Recarga el formulario e inténtalo otra vez."), { status: 403 });
  }
}

function cleanFilename(value: string) {
  const base = value.normalize("NFKC").replace(/[^a-zA-Z0-9._-]+/g, "-").replace(/^-+|-+$/g, "").slice(-90);
  return base || "comprobante";
}

async function hasExpectedSignature(file: File) {
  const bytes = new Uint8Array(await file.slice(0, 8).arrayBuffer());
  if (file.type === "application/pdf") return new TextDecoder().decode(bytes.slice(0, 5)) === "%PDF-";
  if (file.type === "image/jpeg") return bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
  if (file.type === "image/png") return [137, 80, 78, 71, 13, 10, 26, 10].every((value, index) => bytes[index] === value);
  return false;
}

async function masterUser(request: Request, db: D1Database) {
  await ensureLocalAuthSchema(db);
  const user = await getSessionUserFromCookieHeader(db, request.headers.get("cookie"));
  if (!user || user.mustChangePassword) throw Object.assign(new Error("Ingresa con la cuenta Master para revisar las solicitudes."), { status: 401 });
  const record = await db.prepare("SELECT role, active FROM app_users WHERE email = ?").bind(user.email.toLowerCase()).first<{ role: string; active: number }>();
  if (!record || record.role !== "master" || Number(record.active) !== 1) {
    throw Object.assign(new Error("Solo el usuario Master puede revisar las inscripciones."), { status: 403 });
  }
  return user;
}

function apiError(error: unknown) {
  const status = typeof error === "object" && error && "status" in error ? Number(error.status) : 500;
  const message = error instanceof Error ? error.message : "No se pudo completar la solicitud.";
  return json({ error: message }, status);
}

export async function GET(request: Request) {
  try {
    if (!env.DB) throw Object.assign(new Error("La base del campeonato no está disponible."), { status: 503 });
    const user = await masterUser(request, env.DB);
    const rows = await env.DB.prepare(`SELECT r.id, r.category_id AS categoryId, r.sport_id AS sportId,
      r.parallel, r.team_name AS teamName, r.teacher_name AS teacherName, r.captain, r.contact_phone AS contactPhone,
      r.contact_email AS contactEmail, r.roster_json AS rosterJson, r.payer_name AS payerName,
      r.amount_cents AS amountCents, r.payment_method AS paymentMethod, r.payment_date AS paymentDate,
      r.payment_reference AS paymentReference, r.proof_name AS proofName, r.proof_type AS proofType,
      r.proof_size AS proofSize, r.status, r.decision_note AS decisionNote, r.created_at AS createdAt,
      r.reviewed_by AS reviewedBy, r.reviewed_at AS reviewedAt, c.name AS categoryName, s.name AS sportName
      FROM registrations r JOIN categories c ON c.id = r.category_id JOIN sports s ON s.id = r.sport_id
      ORDER BY CASE r.status WHEN 'pending' THEN 0 WHEN 'processing' THEN 1 WHEN 'approved' THEN 2 ELSE 3 END,
      r.created_at DESC`).all<Record<string, unknown>>();
    return json({ registrations: (rows.results ?? []).map((row) => ({
      ...row,
      roster: (() => { try { const parsed = JSON.parse(String(row.rosterJson)); return Array.isArray(parsed) ? parsed : []; } catch { return []; } })(),
      rosterJson: undefined,
      proofUrl: `/api/inscripciones/comprobante?id=${encodeURIComponent(String(row.id))}`,
      submittedBy: user.displayName,
    })) });
  } catch (error) { return apiError(error); }
}

export async function POST(request: Request) {
  let storedKey: string | null = null;
  try {
    requireSameOrigin(request);
    if (!env.DB || !env.BUCKET) throw Object.assign(new Error("El formulario está terminando de configurarse. Inténtalo más tarde."), { status: 503 });
    const today = guayaquilToday();
    if (today < OPEN_DATE || today > CLOSE_DATE) {
      throw Object.assign(new Error("Las inscripciones se reciben del 5 al 9 de octubre de 2026."), { status: 409 });
    }
    const form = await request.formData();
    if (text(form.get("website"), 150)) return json({ ok: true });

    const categoryId = text(form.get("categoryId"), 80);
    const sportId = text(form.get("sportId"), 40);
    const parallel = text(form.get("parallel"), 12).toUpperCase();
    const teacherName = text(form.get("teacherName"), 100);
    const captain = text(form.get("captain"), 100);
    const contactPhone = text(form.get("contactPhone"), 24).replace(/[\s()-]/g, "");
    const contactEmail = text(form.get("contactEmail"), 160).toLowerCase();
    const payerName = text(form.get("payerName"), 100);
    const paymentMethod = text(form.get("paymentMethod"), 20);
    const paymentDate = text(form.get("paymentDate"), 10);
    const paymentReference = text(form.get("paymentReference"), 60);
    const amountValue = text(form.get("amountPaid"), 14).replace(",", ".");
    const amountCents = /^\d{1,5}(?:\.\d{1,2})?$/.test(amountValue) ? Math.round(Number(amountValue) * 100) : 0;
    const roster = [...new Set(text(form.get("roster"), 5000).split(/\r?\n/).map((name) => name.trim().slice(0, 80)).filter(Boolean))];
    const confirmed = form.get("authorization") === "on";
    const file = form.get("proof");

    if (!categoryId || !sportId || !/^[A-Z0-9ÁÉÍÓÚÜÑ-]{1,12}$/.test(parallel)) throw new Error("Selecciona un curso y escribe un paralelo válido.");
    if (!/^(futbol|basquet)$/.test(sportId)) throw new Error("Selecciona fútbol o básquet.");
    if (!teacherName || !captain || !/^\+?\d{9,13}$/.test(contactPhone)) throw new Error("Completa docente responsable, capitán y un teléfono válido.");
    if (contactEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contactEmail)) throw new Error("Revisa el correo de contacto.");
    if (roster.length < 2 || roster.length > 30 || !roster.some((name) => name.toLowerCase() === captain.toLowerCase())) throw new Error("Escribe de 2 a 30 participantes, incluyendo al capitán, uno por línea.");
    if (!payerName || amountCents < 1 || !["transferencia", "depósito"].includes(paymentMethod)) throw new Error("Completa quién realizó el pago, el valor y el método de pago.");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(paymentDate) || paymentDate > today) throw new Error("Selecciona la fecha real del pago.");
    if (!confirmed) throw new Error("Confirma que cuentas con autorización para enviar los datos del equipo.");
    if (!(file instanceof File) || !file.size || file.size > MAX_RECEIPT_BYTES || !ALLOWED_TYPES.has(file.type) || !await hasExpectedSignature(file)) {
      throw new Error("Adjunta un comprobante PDF, JPG o PNG válido de hasta 4 MB.");
    }

    const category = await env.DB.prepare("SELECT name FROM categories WHERE id = ? AND active = 1").bind(categoryId).first<{ name: string }>();
    const sport = await env.DB.prepare("SELECT name FROM sports WHERE id = ? AND active = 1 AND id IN ('futbol', 'basquet')").bind(sportId).first<{ name: string }>();
    if (!category || !sport) throw new Error("Ese curso o deporte ya no está disponible. Actualiza el formulario.");
    const duplicate = await env.DB.prepare(`SELECT id FROM registrations WHERE category_id = ? AND sport_id = ?
      AND parallel = ? AND status IN ('pending', 'processing', 'approved') LIMIT 1`)
      .bind(categoryId, sportId, parallel).first();
    if (duplicate) throw Object.assign(new Error("Ya existe una solicitud o un equipo registrado para ese curso, paralelo y deporte."), { status: 409 });

    const id = crypto.randomUUID();
    const fileExtension = file.type === "application/pdf" ? "pdf" : file.type === "image/png" ? "png" : "jpg";
    storedKey = `comprobantes/${id}.${fileExtension}`;
    await env.BUCKET.put(storedKey, await file.arrayBuffer(), {
      httpMetadata: { contentType: "application/octet-stream", cacheControl: "private, no-store" },
    });
    try {
      await env.DB.prepare(`INSERT INTO registrations (id, category_id, sport_id, parallel, team_name,
        teacher_name, captain, contact_phone, contact_email, roster_json, payer_name, amount_cents,
        payment_method, payment_date, payment_reference, proof_object_key, proof_name, proof_type, proof_size)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
        .bind(id, categoryId, sportId, parallel, `${category.name} ${parallel}`, teacherName, captain,
          contactPhone, contactEmail, JSON.stringify(roster), payerName, amountCents, paymentMethod,
          paymentDate, paymentReference, storedKey, cleanFilename(file.name), file.type, file.size).run();
    } catch (error) {
      await env.BUCKET.delete(storedKey);
      storedKey = null;
      throw error;
    }
    return json({ ok: true, message: "Solicitud enviada. El Master revisará el equipo y el comprobante antes de aprobarlo." }, 201);
  } catch (error) {
    if (storedKey && env.BUCKET) await env.BUCKET.delete(storedKey).catch(() => undefined);
    return apiError(error);
  }
}

export async function PATCH(request: Request) {
  try {
    requireSameOrigin(request);
    if (!env.DB) throw Object.assign(new Error("La base del campeonato no está disponible."), { status: 503 });
    const user = await masterUser(request, env.DB);
    const body = await request.json() as Record<string, unknown>;
    const id = text(body.id, 80);
    const action = text(body.action, 20);
    const note = text(body.note, 300);
    if (!id || !["approve", "reject"].includes(action)) throw new Error("Selecciona una solicitud y una decisión válida.");
    const registration = await env.DB.prepare(`SELECT r.*, c.name AS category_name FROM registrations r
    JOIN categories c ON c.id = r.category_id WHERE r.id = ?`).bind(id).first<RegistrationRow & {
      category_id: string;
      sport_id: string;
      category_name: string;
    }>();
    if (!registration) throw Object.assign(new Error("No se encontró la solicitud."), { status: 404 });
    if (registration.status !== "pending") throw Object.assign(new Error("Esta solicitud ya fue revisada."), { status: 409 });

    if (action === "reject") {
      const result = await env.DB.prepare(`UPDATE registrations SET status = 'rejected', decision_note = ?,
        reviewed_by = ?, reviewed_at = CURRENT_TIMESTAMP WHERE id = ? AND status = 'pending'`)
        .bind(note || "Solicitud no aprobada por el Master.", user.email, id).run();
      if (!result.meta.changes) throw Object.assign(new Error("La solicitud ya no está pendiente."), { status: 409 });
      return json({ ok: true, message: "Solicitud marcada como no aprobada." });
    }

    const alreadyEntered = await env.DB.prepare("SELECT id FROM teams WHERE category_id = ? AND sport_id = ? AND parallel = ? LIMIT 1")
      .bind(registration.category_id, registration.sport_id, registration.parallel).first();
    if (alreadyEntered) throw Object.assign(new Error("Ese paralelo ya está cargado en Equipos. Revisa el duplicado antes de aprobar."), { status: 409 });
    const teamId = crypto.randomUUID();
    const batch = await env.DB.batch([
      env.DB.prepare("UPDATE registrations SET status = 'processing' WHERE id = ? AND status = 'pending'").bind(id),
      env.DB.prepare(`INSERT INTO teams (id, category_id, sport_id, parallel, name, captain, teacher,
        jersey_color, roster_json) SELECT ?, category_id, sport_id, parallel, team_name, captain,
        teacher_name, '#1d4ed8', roster_json FROM registrations WHERE id = ? AND status = 'processing'`)
        .bind(teamId, id),
      env.DB.prepare(`UPDATE registrations SET status = 'approved', team_id = ?, decision_note = ?,
        reviewed_by = ?, reviewed_at = CURRENT_TIMESTAMP WHERE id = ? AND status = 'processing'`)
        .bind(teamId, note, user.email, id),
    ]);
    if (!batch[0]?.meta.changes) throw Object.assign(new Error("La solicitud ya no está pendiente."), { status: 409 });
    return json({ ok: true, message: `${registration.category_name} ${registration.parallel} ya quedó cargado en Equipos.` });
  } catch (error) { return apiError(error); }
}
