import { env } from "cloudflare:workers";
import { ensureLocalAuthSchema, getSessionUserFromCookieHeader } from "../../../local-auth";

export async function GET(request: Request) {
  const db = env.DB;
  const bucket = env.BUCKET;
  if (!db || !bucket) return new Response("El comprobante no está disponible.", { status: 503 });
  await ensureLocalAuthSchema(db);
  const session = await getSessionUserFromCookieHeader(db, request.headers.get("cookie"));
  if (!session || session.mustChangePassword) return new Response("Acceso Master requerido.", { status: 401 });
  const role = await db.prepare("SELECT role, active FROM app_users WHERE email = ?").bind(session.email.toLowerCase()).first<{ role: string; active: number }>();
  if (!role || role.role !== "master" || Number(role.active) !== 1) return new Response("Acceso Master requerido.", { status: 403 });
  const id = new URL(request.url).searchParams.get("id")?.slice(0, 80) ?? "";
  if (!id) return new Response("Falta el comprobante.", { status: 400 });
  const record = await db.prepare("SELECT proof_object_key AS objectKey, proof_type AS contentType, proof_name AS filename FROM registrations WHERE id = ?")
    .bind(id).first<{ objectKey: string; contentType: string; filename: string }>();
  if (!record) return new Response("No se encontró el comprobante.", { status: 404 });
  const object = await bucket.get(record.objectKey);
  if (!object) return new Response("El archivo no está disponible.", { status: 404 });
  const safeName = record.filename.replace(/[\r\n"\\]/g, "_").slice(0, 90);
  return new Response(object.body, {
    headers: {
      "Content-Type": "application/octet-stream",
      "Content-Disposition": `attachment; filename="${safeName}"`,
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
      "Content-Length": String(object.size),
    },
  });
}
