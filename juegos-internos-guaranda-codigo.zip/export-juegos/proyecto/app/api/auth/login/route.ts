import { env } from "cloudflare:workers";
import {
  createSession,
  ensureLocalAuthSchema,
  getLoginKey,
  normalizeUsername,
  verifyPassword,
} from "../../../local-auth";

function json(data: unknown, status = 200, cookie?: string) {
  const headers = new Headers({ "Cache-Control": "no-store", "Content-Type": "application/json" });
  if (cookie) headers.append("Set-Cookie", cookie);
  return new Response(JSON.stringify(data), { status, headers });
}

function assertSameOrigin(request: Request) {
  const origin = request.headers.get("origin");
  if (origin && new URL(origin).origin !== new URL(request.url).origin) {
    throw new Error("ORIGIN");
  }
}

export async function POST(request: Request) {
  try {
    assertSameOrigin(request);
    if (!env.DB) return json({ error: "El sistema está iniciando. Intenta de nuevo en unos minutos." }, 503);
    const db = env.DB;
    await ensureLocalAuthSchema(db);
    const body = await request.json() as { username?: unknown; password?: unknown };
    const username = normalizeUsername(body.username);
    const password = typeof body.password === "string" ? body.password : "";
    if (!username || !password || username.length > 32 || password.length > 128) {
      return json({ error: "Escribe tu usuario y contraseña." }, 400);
    }

    const loginKey = await getLoginKey(username);
    const attempts = await db.prepare("SELECT failed_count AS failedCount, window_started_at AS windowStartedAt, locked_until AS lockedUntil FROM auth_login_attempts WHERE login_key = ?")
      .bind(loginKey).first<{ failedCount: number; windowStartedAt: string; lockedUntil: string | null }>();
    const now = Date.now();
    if (attempts?.lockedUntil && Date.parse(attempts.lockedUntil) > now) {
      return json({ error: "Demasiados intentos. Espera 15 minutos y vuelve a intentar." }, 429);
    }

    const record = await db.prepare(`SELECT u.email, u.display_name AS displayName, u.active, u.role,
        c.username, c.password_salt AS passwordSalt, c.password_hash AS passwordHash,
        c.must_change_password AS mustChangePassword
      FROM app_credentials c JOIN app_users u ON u.email = c.email
      WHERE c.username = ? COLLATE NOCASE LIMIT 1`).bind(username).first<{
      email: string;
      displayName: string;
      active: number;
      role: "master" | "docente";
      username: string;
      passwordSalt: string;
      passwordHash: string;
      mustChangePassword: number;
    }>();

    const passwordMatches = record
      ? await verifyPassword(password, record.passwordSalt, record.passwordHash)
      : await verifyPassword(password, "AAAAAAAAAAAAAAAAAAAAAA", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
    if (!record || Number(record.active) !== 1 || !passwordMatches) {
      const windowStillOpen = attempts && now - Date.parse(attempts.windowStartedAt) < 15 * 60 * 1000;
      const failedCount = windowStillOpen ? Number(attempts.failedCount) + 1 : 1;
      const windowStartedAt = windowStillOpen ? attempts.windowStartedAt : new Date(now).toISOString();
      const lockedUntil = failedCount >= 5 ? new Date(now + 15 * 60 * 1000).toISOString() : null;
      await db.prepare(`INSERT INTO auth_login_attempts (login_key, failed_count, window_started_at, locked_until)
        VALUES (?, ?, ?, ?) ON CONFLICT(login_key) DO UPDATE SET failed_count = excluded.failed_count,
        window_started_at = excluded.window_started_at, locked_until = excluded.locked_until`)
        .bind(loginKey, failedCount, windowStartedAt, lockedUntil).run();
      return json({ error: "Usuario o contraseña incorrectos, o cuenta desactivada." }, 401);
    }

    await db.prepare("DELETE FROM auth_login_attempts WHERE login_key = ?").bind(loginKey).run();
    const session = await createSession(db, record.email, request.url);
    return json({
      ok: true,
      mustChangePassword: Number(record.mustChangePassword) === 1,
      displayName: record.displayName,
    }, 200, session.cookie);
  } catch (error) {
    if (error instanceof Error && error.message === "ORIGIN") {
      return json({ error: "No se pudo validar el ingreso. Actualiza la página e inténtalo de nuevo." }, 403);
    }
    return json({ error: "No se pudo iniciar sesión. Intenta de nuevo." }, 500);
  }
}
