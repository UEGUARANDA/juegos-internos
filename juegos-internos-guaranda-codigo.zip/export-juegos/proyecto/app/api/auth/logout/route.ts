import { env } from "cloudflare:workers";
import { expiredSessionCookie, getCookie, SESSION_COOKIE } from "../../../local-auth";

export async function GET(request: Request) {
  if (env.DB) {
    const token = getCookie(request.headers.get("cookie") ?? "", SESSION_COOKIE);
    if (token) {
      const bytes = new TextEncoder().encode(token);
      const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", bytes));
      let binary = "";
      for (const byte of digest) binary += String.fromCharCode(byte);
      const tokenHash = btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/g, "");
      await env.DB.prepare("DELETE FROM app_sessions WHERE token_hash = ?").bind(tokenHash).run();
    }
  }
  return new Response(null, {
    status: 303,
    headers: {
      Location: new URL("/gestion", request.url).toString(),
      "Cache-Control": "no-store",
      "Set-Cookie": expiredSessionCookie(request.url),
    },
  });
}
