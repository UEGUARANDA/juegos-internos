import { env } from "cloudflare:workers";
import {
  createSession,
  ensureLocalAuthSchema,
  getSessionUserFromCookieHeader,
  newPasswordSalt,
  hashPassword,
} from "../../../local-auth";

function json(data: unknown, status = 200, cookie?: string) {
  const headers = new Headers({ "Cache-Control": "no-store", "Content-Type": "application/json" });
  if (cookie) headers.append("Set-Cookie", cookie);
  return new Response(JSON.stringify(data), { status, headers });
}

export async function POST(request: Request) {
  const origin = request.headers.get("origin");
  if (origin && new URL(origin).origin !== new URL(request.url).origin) {
    return json({ error: "No se pudo validar la solicitud." }, 403);
  }
  if (!env.DB) return json({ error: "El sistema está iniciando. Intenta de nuevo." }, 503);
  const db = env.DB;
  await ensureLocalAuthSchema(db);
  const user = await getSessionUserFromCookieHeader(db, request.headers.get("cookie"));
  if (!user) return json({ error: "Tu sesión venció. Ingresa otra vez." }, 401);

  let body: { newPassword?: unknown };
  try {
    body = await request.json() as { newPassword?: unknown };
  } catch {
    return json({ error: "Escribe una contraseña nueva." }, 400);
  }
  const password = typeof body.newPassword === "string" ? body.newPassword : "";
  if (password.length < 12 || password.length > 128) {
    return json({ error: "La nueva contraseña debe tener al menos 12 caracteres." }, 400);
  }

  const salt = newPasswordSalt();
  const passwordHash = await hashPassword(password, salt);
  await db.prepare(`UPDATE app_credentials SET password_salt = ?, password_hash = ?, must_change_password = 0 WHERE email = ?`)
    .bind(salt, passwordHash, user.email).run();
  await db.prepare("DELETE FROM app_sessions WHERE email = ?").bind(user.email).run();
  const session = await createSession(db, user.email, request.url);
  return json({ ok: true }, 200, session.cookie);
}
