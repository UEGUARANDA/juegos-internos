"use client";

import {
  Activity,
  ClipboardCheck,
  ArrowDownToLine,
  ArrowRight,
  Copy,
  CalendarDays,
  Check,
  CheckCircle2,
  CircleHelp,
  ClipboardList,
  Clock3,
  FileSpreadsheet,
  Flag,
  Medal,
  Menu,
  LogOut,
  Plus,
  KeyRound,
  RefreshCw,
  Settings2,
  ShieldCheck,
  Shuffle,
  Sparkles,
  Trophy,
  UsersRound,
  Volleyball,
  X,
} from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import { useCallback, useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import { calculateStandings } from "../lib/standings";
import InscripcionesPanel from "./gestion/inscripciones-panel";
import InstallAppButton from "./pwa-install";

type Config = {
  tournamentName: string;
  season: string;
  schoolName: string;
  areaResponsible: string;
  rector: string;
};
type Sport = {
  id: string;
  name: string;
  active: number | boolean;
  winPoints: number;
  drawPoints: number;
  lossPoints: number;
  allowDraw: number | boolean;
  sortOrder: number;
};
type Category = { id: string; name: string; sortOrder: number; active: number | boolean };
type Team = {
  id: string;
  categoryId: string;
  sportId: string;
  parallel: string;
  name: string;
  captain: string;
  teacher: string;
  jerseyColor: string;
  roster: string[];
};
type Match = {
  id: string;
  drawId: string | null;
  categoryId: string;
  sportId: string;
  phase: string;
  roundNo: number;
  roundLabel: string;
  homeTeamId: string | null;
  awayTeamId: string | null;
  homeName: string | null;
  awayName: string | null;
  homeColor: string | null;
  awayColor: string | null;
  matchDate: string | null;
  matchTime: string | null;
  venue: string;
  status: string;
  scoreHome: number | null;
  scoreAway: number | null;
  detail: Record<string, unknown>;
  winnerOverride: string | null;
  categoryName: string;
  sportName: string;
};
type AppState = {
  config: Config;
  sports: Sport[];
  categories: Category[];
  teams: Team[];
  matches: Match[];
  recentActivity: Array<{ id: string; action: string; actorEmail: string; createdAt: string }>;
  user: { displayName: string; email: string; username: string };
  accessRole: "master" | "docente";
  staffUsers: Array<{ email: string; username: string | null; displayName: string; role: "master" | "docente"; active: number | boolean; createdAt: string }>;
  pendingRegistrations: number;
};
type Page = "inicio" | "inscripciones" | "equipos" | "partidos" | "posiciones" | "configuracion";
const teacherPages: Page[] = ["inicio", "partidos", "posiciones"];

const navItems: Array<{ id: Page; label: string; icon: typeof Activity }> = [
  { id: "inicio", label: "Resumen", icon: Activity },
  { id: "inscripciones", label: "Inscripciones", icon: ClipboardCheck },
  { id: "equipos", label: "Equipos", icon: UsersRound },
  { id: "partidos", label: "Sorteos y partidos", icon: CalendarDays },
  { id: "posiciones", label: "Posiciones", icon: Medal },
  { id: "configuracion", label: "Configuración", icon: Settings2 },
];

const pageTitles: Record<Page, string> = {
  inicio: "Resumen del campeonato",
  inscripciones: "Solicitudes de inscripción",
  equipos: "Equipos y paralelos",
  partidos: "Sorteos y partidos",
  posiciones: "Tablas de posiciones",
  configuracion: "Configuración del sistema",
};

function localToday() {
  const today = new Date();
  return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
}

function displayDate(value: string | null) {
  if (!value) return "Horario por asignar";
  const date = new Date(`${value}T12:00:00`);
  return new Intl.DateTimeFormat("es-EC", { weekday: "short", day: "numeric", month: "short" }).format(date);
}

function csvDownload(filename: string, rows: Array<Array<string | number>>) {
  const content = rows
    .map((row) => row.map((cell) => `"${String(cell ?? "").replaceAll('"', '""')}"`).join(","))
    .join("\r\n");
  const blob = new Blob(["\ufeff", content], { type: "text/csv;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
  URL.revokeObjectURL(link.href);
}

function phaseLabel(phase: string) {
  if (phase === "round_robin") return "Primera fase";
  if (phase === "semifinal") return "Semifinal";
  if (phase === "third_place") return "Tercer puesto";
  return "Final";
}

function groupLabel(match: Match) {
  if (match.phase === "round_robin") return match.roundLabel;
  return phaseLabel(match.phase);
}

function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <section className={`card ${className}`}>{children}</section>;
}

function EmptyState({ icon: Icon, title, text }: { icon: typeof CircleHelp; title: string; text: string }) {
  return (
    <div className="empty-state">
      <span className="empty-icon"><Icon size={22} /></span>
      <strong>{title}</strong>
      <p>{text}</p>
    </div>
  );
}

export default function TorneoApp({
  user,
  signOutHref,
}: {
  user: { displayName: string; email: string; username: string };
  signOutHref: string;
}) {
  const [state, setState] = useState<AppState | null>(null);
  const [page, setPage] = useState<Page>("inicio");
  const [categoryId, setCategoryId] = useState("8vo");
  const [sportId, setSportId] = useState("futbol");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState<{ type: "success" | "error" | "info"; message: string } | null>(null);
  const [issuedCredential, setIssuedCredential] = useState<{ username: string; password: string } | null>(null);
  const [teamModal, setTeamModal] = useState(false);
  const [resultMatch, setResultMatch] = useState<Match | null>(null);
  const [scheduleMatch, setScheduleMatch] = useState<Match | null>(null);
  const [mobileMenu, setMobileMenu] = useState(false);
  const updatePendingCount = useCallback((count: number) => {
    setState((current) => current ? { ...current, pendingRegistrations: count } : current);
  }, []);

  const refresh = useCallback(async function refresh() {
    try {
      const response = await fetch("/api/data", { cache: "no-store" });
      const payload = (await response.json()) as Partial<AppState> & { error?: string };
      if (!response.ok) throw new Error(payload.error || "No se pudo cargar el sistema.");
      setState(payload as AppState);
      const categories = payload.categories ?? [];
      const sports = payload.sports ?? [];
      if (categories.length) {
        setCategoryId((current) => categories.some((item: Category) => item.id === current) ? current : categories[0].id);
      }
      if (sports.length) {
        setSportId((current) => sports.some((item: Sport) => item.id === current) ? current : sports[0].id);
      }
    } catch (error) {
      setNotice({ type: "error", message: error instanceof Error ? error.message : "No se pudo abrir el campeonato." });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => void refresh(), 0);
    // The first load is the only automatic request; saved actions refresh explicitly.
    return () => window.clearTimeout(timer);
  }, [refresh]);

  function showNotice(message: string, type: "success" | "error" | "info" = "success") {
    setNotice({ type, message });
    window.setTimeout(() => setNotice(null), 5500);
  }

  async function act(payload: Record<string, unknown>, successMessage?: string) {
    setSaving(true);
    try {
      const response = await fetch("/api/data", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = (await response.json()) as { error?: string; state?: AppState; message?: string; temporaryCredential?: { username: string; password: string } };
      if (!response.ok) throw new Error(result.error || "No se pudieron guardar los cambios.");
      if (result.state) setState(result.state as AppState);
      if (result.temporaryCredential) setIssuedCredential(result.temporaryCredential);
      showNotice(result.message || successMessage || "Cambios guardados correctamente.");
      return true;
    } catch (error) {
      showNotice(error instanceof Error ? error.message : "No se pudieron guardar los cambios.", "error");
      return false;
    } finally {
      setSaving(false);
    }
  }

  const activeCategories = useMemo(() => (state?.categories ?? []).filter((item) => Boolean(item.active)), [state]);
  const activeSports = useMemo(() => (state?.sports ?? []).filter((item) => Boolean(item.active)), [state]);
  const selectedCategory = activeCategories.find((item) => item.id === categoryId) ?? activeCategories[0];
  const selectedSport = activeSports.find((item) => item.id === sportId) ?? activeSports[0];
  const selectedTeams = (state?.teams ?? []).filter((team) => team.categoryId === categoryId && team.sportId === sportId);
  const selectedMatches = (state?.matches ?? []).filter((match) => match.categoryId === categoryId && match.sportId === sportId);
  const leagueMatches = selectedMatches.filter((match) => match.phase === "round_robin");
  const standingRows = selectedSport
    ? calculateStandings(selectedTeams, selectedMatches, selectedSport)
    : [];
  const drawableCount = Math.floor((selectedTeams.length * (selectedTeams.length - 1)) / 2);
  const completedLeague = leagueMatches.length > 0 && leagueMatches.filter((match) => match.status !== "bye").every((match) => match.status === "finished");

  const pageDescription: Record<Page, string> = {
    inicio: state?.accessRole === "master"
      ? "Organiza el campeonato en pocos pasos y consulta su avance de un vistazo."
      : "Consulta los encuentros y registra o corrige sus resultados.",
    inscripciones: "Revisa nóminas y comprobantes; al aprobar, el equipo pasa al campeonato.",
    equipos: "Registra cada paralelo por separado para cada deporte.",
    partidos: state?.accessRole === "master"
      ? "Sortea enfrentamientos, programa horarios y registra los marcadores."
      : "Consulta el calendario y registra o corrige los marcadores.",
    posiciones: "Las posiciones se actualizan automáticamente al guardar cada resultado.",
    configuracion: "Actualiza los datos oficiales, cursos y reglas antes de iniciar.",
  };
  const visibleNavItems = state?.accessRole === "master"
    ? navItems
    : navItems.filter((item) => teacherPages.includes(item.id)).map((item) =>
      item.id === "partidos" ? { ...item, label: "Partidos y resultados" } : item,
    );

  function enterPage(target: Page) {
    if (state?.accessRole === "docente" && !teacherPages.includes(target)) return;
    setPage(target);
    setMobileMenu(false);
  }

  if (loading) {
    return (
      <div className="loading-screen">
        <div className="loading-mark"><Trophy size={25} /></div>
        <strong>Preparando el campeonato</strong>
        <span>Cargando cursos, equipos y partidos…</span>
      </div>
    );
  }

  if (!state) {
    return (
      <div className="loading-screen">
        <div className="loading-mark"><ShieldCheck size={25} /></div>
        <strong>No se pudo abrir el campeonato</strong>
        <span>{notice?.message ?? "Revisa tu conexión e inténtalo otra vez."}</span>
        <button className="button button-primary" onClick={() => { setLoading(true); void refresh(); }}><RefreshCw size={16} /> Reintentar</button>
      </div>
    );
  }

  const upcoming = state.matches
    .filter((match) => match.status === "pending" && match.homeTeamId && match.awayTeamId)
    .sort((a, b) => `${a.matchDate ?? "9999-12-31"} ${a.matchTime ?? "23:59"}`.localeCompare(`${b.matchDate ?? "9999-12-31"} ${b.matchTime ?? "23:59"}`))
    .slice(0, 5);
  const finished = state.matches.filter((match) => match.status === "finished").length;
  const pending = state.matches.filter((match) => match.status === "pending" && match.homeTeamId && match.awayTeamId).length;
  const completion = state.matches.filter((match) => match.status !== "bye").length
    ? Math.round((finished / state.matches.filter((match) => match.status !== "bye").length) * 100)
    : 0;

  function renderMatchCard(match: Match) {
    if (match.status === "bye") {
      const restName = match.homeName ?? "Equipo";
      return (
        <div className="match-card bye-card" key={match.id}>
          <div className="match-meta"><span className="round-pill">{groupLabel(match)}</span><span>Descanso de la fecha</span></div>
          <div className="bye-copy"><span className="team-dot" style={{ background: match.homeColor ?? "#1c6b51" }} />{restName}<span>descansa esta fecha</span></div>
        </div>
      );
    }
    const finishedMatch = match.status === "finished";
    return (
      <div className="match-card" key={match.id}>
        <div className="match-meta">
          <span className={`round-pill ${match.phase !== "round_robin" ? "round-pill-final" : ""}`}>{groupLabel(match)}</span>
          <span className={finishedMatch ? "status status-done" : "status status-pending"}>{finishedMatch ? "Resultado registrado" : "Pendiente"}</span>
        </div>
        <div className="match-versus">
          <div className="match-side">
            <span className="team-dot" style={{ background: match.homeColor ?? "#1c6b51" }} />
            <strong>{match.homeName ?? "Equipo local"}</strong>
            <b className="match-score">{finishedMatch ? match.scoreHome : "—"}</b>
          </div>
          <span className="versus">VS</span>
          <div className="match-side match-side-away">
            <span className="team-dot" style={{ background: match.awayColor ?? "#d89637" }} />
            <strong>{match.awayName ?? "Equipo visitante"}</strong>
            <b className="match-score">{finishedMatch ? match.scoreAway : "—"}</b>
          </div>
        </div>
        <div className="match-footer">
          <span><CalendarDays size={14} /> {displayDate(match.matchDate)}{match.matchTime ? ` · ${match.matchTime}` : ""}</span>
          <span><Flag size={14} /> {match.venue || "Por asignar"}</span>
          <div className="match-actions">
            {state?.accessRole === "master" ? <button className="text-button" onClick={() => setScheduleMatch(match)}><Clock3 size={14} /> Horario</button> : null}
            <button className="button button-small button-outline" onClick={() => setResultMatch(match)}>{finishedMatch ? "Editar marcador" : "Registrar marcador"}</button>
          </div>
        </div>
      </div>
    );
  }

  const pageContent = (() => {
    if (page === "inicio") {
      return (
        <>
          <section className="welcome-panel">
            <div>
              <p className="eyebrow">{state.config.season} · CAMPEONATO ESCOLAR</p>
              <h2>Que comiencen los juegos.</h2>
              <p>{state.accessRole === "master" ? "Un solo lugar para inscribir paralelos, sortear partidos y seguir cada deporte." : "Revisa los próximos encuentros y carga los resultados de cada partido."}</p>
              <div className="welcome-actions">
                {state.accessRole === "master" ? <button className="button button-light" onClick={() => { setTeamModal(true); enterPage("equipos"); }}><Plus size={16} /> Inscribir equipo</button> : null}
                <button className="welcome-link" onClick={() => enterPage("partidos")}>{state.accessRole === "master" ? "Ir al calendario" : "Ver encuentros"} <ArrowRight size={16} /></button>
                {state.accessRole === "docente" ? <button className="welcome-link" onClick={() => enterPage("posiciones")}>Ver posiciones <ArrowRight size={16} /></button> : null}
              </div>
            </div>
            <div className="welcome-art" aria-hidden="true">
              <div className="art-ring art-ring-one" /><div className="art-ring art-ring-two" />
              <div className="art-trophy"><Trophy size={64} strokeWidth={1.35} /></div>
              <span className="art-ball ball-one" /><span className="art-ball ball-two" />
              <div className="art-tag"><Sparkles size={14} /> Todo organizado</div>
            </div>
          </section>

          <div className="stats-grid">
            <div className="stat-card"><span className="stat-icon stat-green"><UsersRound size={19} /></span><div><span>Equipos inscritos</span><strong>{state.teams.length}</strong></div><small>{activeCategories.length} cursos activos</small></div>
            <div className="stat-card"><span className="stat-icon stat-blue"><CalendarDays size={19} /></span><div><span>Partidos programados</span><strong>{pending}</strong></div><small>en todos los deportes</small></div>
            <div className="stat-card"><span className="stat-icon stat-gold"><CheckCircle2 size={19} /></span><div><span>Resultados cargados</span><strong>{finished}</strong></div><small>posiciones actualizadas</small></div>
            <div className="stat-card"><span className="stat-icon stat-lilac"><Trophy size={19} /></span><div><span>Avance general</span><strong>{completion}%</strong></div><small>del calendario generado</small></div>
          </div>

          <div className="dashboard-grid">
            <Card className="dashboard-main-card">
              <div className="section-heading"><div><span className="eyebrow">CALENDARIO</span><h3>Próximos partidos</h3></div><button className="text-button" onClick={() => enterPage("partidos")}>Ver calendario <ArrowRight size={15} /></button></div>
              {upcoming.length ? (
                <div className="upcoming-list">{upcoming.map((match) => (
                  <button className="upcoming-row" key={match.id} onClick={() => { setCategoryId(match.categoryId); setSportId(match.sportId); enterPage("partidos"); }}>
                    <div className="upcoming-date"><strong>{match.matchDate ? match.matchDate.slice(8, 10) : "—"}</strong><span>{match.matchDate ? new Intl.DateTimeFormat("es-EC", { month: "short" }).format(new Date(`${match.matchDate}T12:00:00`)) : "sin fecha"}</span></div>
                    <div className="upcoming-teams"><strong>{match.homeName} <span>vs</span> {match.awayName}</strong><small>{match.categoryName} · {match.sportName}</small></div>
                    <div className="upcoming-time">{match.matchTime ? <><Clock3 size={14} /> {match.matchTime}</> : "Por programar"}</div>
                    <ArrowRight className="upcoming-arrow" size={16} />
                  </button>
                ))}</div>
              ) : <EmptyState icon={CalendarDays} title="Todavía no hay partidos" text="Inscribe los equipos y realiza el sorteo para generar el calendario." />}
            </Card>
            <Card className="progress-card">
              <div className="section-heading"><div><span className="eyebrow">ESTADO</span><h3>Avance del campeonato</h3></div><span className="progress-number">{completion}%</span></div>
              <div className="progress-track"><span style={{ width: `${completion}%` }} /></div>
              <p>{finished} de {state.matches.filter((match) => match.status !== "bye").length} partidos tienen resultado.</p>
              <div className="progress-divider" />
              <div className="quick-actions-title">Acciones rápidas</div>
              {state.accessRole === "master" ? <>
                <button className="quick-action" onClick={() => { setTeamModal(true); enterPage("equipos"); }}><span className="quick-icon"><Plus size={16} /></span><span><strong>Registrar un equipo</strong><small>Agrega un paralelo y su lista</small></span><ArrowRight size={15} /></button>
                <button className="quick-action" onClick={() => enterPage("partidos")}><span className="quick-icon quick-icon-gold"><Shuffle size={16} /></span><span><strong>Hacer un sorteo</strong><small>Genera los cruces al azar</small></span><ArrowRight size={15} /></button>
              </> : <>
                <button className="quick-action" onClick={() => enterPage("partidos")}><span className="quick-icon quick-icon-gold"><CheckCircle2 size={16} /></span><span><strong>Registrar un resultado</strong><small>Abre el calendario de encuentros</small></span><ArrowRight size={15} /></button>
                <button className="quick-action" onClick={() => enterPage("posiciones")}><span className="quick-icon"><Medal size={16} /></span><span><strong>Consultar posiciones</strong><small>La tabla se actualiza al guardar</small></span><ArrowRight size={15} /></button>
              </>}
            </Card>
          </div>

          <div className="section-heading sport-heading"><div><span className="eyebrow">DISCIPLINAS</span><h3>Deportes del campeonato</h3></div>{state.accessRole === "master" ? <button className="text-button" onClick={() => enterPage("configuracion")}>Ajustar reglas <Settings2 size={15} /></button> : null}</div>
          <div className="sport-grid">
            {activeSports.map((sport, index) => {
              const sportTeams = state.teams.filter((team) => team.sportId === sport.id).length;
              const sportMatches = state.matches.filter((match) => match.sportId === sport.id);
              const sportDone = sportMatches.filter((match) => match.status === "finished").length;
              const Icon = index === 0 ? Flag : index === 1 ? Activity : Volleyball;
              return <button className="sport-card" key={sport.id} onClick={() => { setSportId(sport.id); enterPage("partidos"); }}>
                <span className={`sport-card-icon sport-icon-${index}`}><Icon size={20} /></span><span className="sport-card-title">{sport.name}</span>
                <span className="sport-card-stats">{sportTeams} equipos · {sportDone}/{sportMatches.filter((match) => match.status !== "bye").length} resultados</span>
                <span className="sport-progress"><i style={{ width: `${sportMatches.filter((match) => match.status !== "bye").length ? sportDone / sportMatches.filter((match) => match.status !== "bye").length * 100 : 0}%` }} /></span>
                <ArrowRight size={16} className="sport-arrow" />
              </button>;
            })}
          </div>
        </>
      );
    }

    if (page === "equipos") {
      return (
        <>
          <div className="filters-row">
            <label>Curso<select value={categoryId} onChange={(event) => setCategoryId(event.target.value)}>{activeCategories.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
            <label>Deporte<select value={sportId} onChange={(event) => setSportId(event.target.value)}>{activeSports.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
            <button className="button button-primary filter-add" onClick={() => setTeamModal(true)}><Plus size={16} /> Inscribir paralelo</button>
          </div>
          <div className="team-page-grid">
            <Card className="team-list-card">
              <div className="section-heading"><div><span className="eyebrow">{selectedCategory?.name ?? "CURSO"} · {selectedSport?.name ?? "DEPORTE"}</span><h3>Paralelos inscritos</h3></div><span className="count-badge">{selectedTeams.length} equipos</span></div>
              {selectedTeams.length ? <div className="team-list">{selectedTeams.map((team, index) => (
                <div className="team-row" key={team.id}>
                  <div className="team-index">{String(index + 1).padStart(2, "0")}</div>
                  <span className="team-avatar" style={{ background: team.jerseyColor }}>{team.parallel}</span>
                  <div className="team-info"><strong>{team.name}</strong><small>{team.roster.length ? `${team.roster.length} estudiantes` : "Lista de jugadores pendiente"}{team.captain ? ` · Capitán: ${team.captain}` : ""}</small></div>
                  {team.teacher ? <span className="team-teacher">{team.teacher}</span> : null}
                  <button className="icon-button danger-on-hover" title="Eliminar equipo" onClick={() => { if (window.confirm(`¿Eliminar ${team.name} de ${selectedSport?.name}?`)) void act({ action: "remove_team", id: team.id }); }}><X size={16} /></button>
                </div>
              ))}</div> : <EmptyState icon={UsersRound} title="Sin equipos inscritos todavía" text="Agrega los paralelos que participarán en este deporte. Cada deporte lleva su propia lista." />}
            </Card>
            <Card className="team-side-card">
              <span className="side-card-icon"><ClipboardList size={22} /></span><span className="eyebrow">ANTES DEL SORTEO</span><h3>Completa los equipos</h3>
              <p>Registra todos los paralelos de {selectedCategory?.name ?? "este curso"} en {selectedSport?.name ?? "este deporte"}. Cuando estén listos, el sistema arma los cruces automáticamente.</p>
              <ul className="check-list"><li><Check size={15} /> Un equipo por paralelo y deporte</li><li><Check size={15} /> Lista de jugadores opcional</li><li><Check size={15} /> Sorteo de todos contra todos</li></ul>
              <button className="button button-primary button-full" onClick={() => { enterPage("partidos"); }}>Ir a sorteos <ArrowRight size={16} /></button>
            </Card>
          </div>
        </>
      );
    }

    if (page === "partidos") {
      const groups = new Map<string, Match[]>();
      for (const match of selectedMatches) {
        const key = `${match.phase}-${match.roundNo}`;
        groups.set(key, [...(groups.get(key) ?? []), match]);
      }
      const matchGroups = [...groups.entries()].sort((a, b) => {
        const phaseOrder = (phase: string) => phase === "round_robin" ? 1 : phase === "semifinal" ? 2 : phase === "third_place" ? 3 : 4;
        const [aPhase, aRound] = a[0].split("-"); const [bPhase, bRound] = b[0].split("-");
        return phaseOrder(aPhase) - phaseOrder(bPhase) || Number(aRound) - Number(bRound);
      });
      const scheduledMatches = selectedMatches.filter((match) => match.matchDate && match.status !== "bye").length;
      return (
        <>
          <div className="filters-row">
            <label>Curso<select value={categoryId} onChange={(event) => setCategoryId(event.target.value)}>{activeCategories.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
            <label>Deporte<select value={sportId} onChange={(event) => setSportId(event.target.value)}>{activeSports.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
            <span className="filter-summary"><UsersRound size={15} /> {selectedTeams.length} equipos · {drawableCount} partidos posibles</span>
          </div>
          {state.accessRole === "master" ? <div className="draw-grid">
            <Card className="draw-card">
              <div className="draw-mark"><Shuffle size={21} /></div><div className="draw-copy"><span className="eyebrow">SORTEO AUTOMÁTICO</span><h3>Arma los cruces por ti</h3><p>El sistema mezcla los paralelos y crea las fechas de todos contra todos. Si el número de equipos es impar, asigna un descanso por fecha.</p></div>
              <div className="draw-side"><strong>{selectedTeams.length}</strong><span>equipos registrados</span><button className="button button-primary" disabled={saving || selectedTeams.length < 2} onClick={() => { const oldDraw = selectedMatches.some((item) => item.phase === "round_robin"); if (oldDraw && !window.confirm("Se volverán a sortear los partidos pendientes de esta categoría. Los resultados ya registrados se conservan y bloquean el nuevo sorteo. ¿Continuar?")) return; void act({ action: "draw", categoryId, sportId }, "Sorteo realizado."); }}><Shuffle size={16} /> {selectedMatches.length ? "Volver a sortear" : "Realizar sorteo"}</button></div>
            </Card>
            <Card className="schedule-card">
              <div className="section-heading"><div><span className="eyebrow">CALENDARIO</span><h3>Programar partidos</h3></div><CalendarDays size={19} className="muted-icon" /></div>
              <p>Asigna horarios consecutivos a todos los partidos pendientes. El calendario continúa al día siguiente según los partidos por jornada.</p>
              <form className="schedule-form" onSubmit={(event: FormEvent<HTMLFormElement>) => { event.preventDefault(); const data = new FormData(event.currentTarget); void act({ action: "schedule_all", startDate: data.get("startDate"), startTime: data.get("startTime"), matchMinutes: data.get("matchMinutes"), breakMinutes: data.get("breakMinutes"), matchesPerDay: data.get("matchesPerDay"), venue: data.get("venue") }, "Horarios asignados al calendario."); }}>
                <label>Fecha de inicio<input required type="date" name="startDate" defaultValue={localToday()} /></label>
                <label>Hora de inicio<input required type="time" name="startTime" defaultValue="08:00" /></label>
                <label>Minutos por partido<input type="number" name="matchMinutes" min="5" max="240" defaultValue="40" /></label>
                <label>Partidos por día<input type="number" name="matchesPerDay" min="1" max="40" defaultValue="8" /></label>
                <label>Descanso entre partidos<input type="number" name="breakMinutes" min="0" max="240" defaultValue="10" /></label>
                <label>Cancha o lugar<input name="venue" maxLength={100} defaultValue="Cancha principal" /></label>
                <button className="button button-primary button-full" disabled={saving || pending === 0}><CalendarDays size={16} /> Programar {pending} partidos</button>
              </form>
              <small className="schedule-saved">{scheduledMatches} partidos ya tienen fecha asignada.</small>
            </Card>
          </div> : <Card className="privacy-card"><div className="privacy-icon"><ShieldCheck size={21} /></div><div><strong>Acceso docente: solo resultados</strong><p>Puedes registrar o corregir marcadores. El usuario Master administra equipos, sorteos y horarios.</p></div></Card>}
          <div className="section-heading list-heading"><div><span className="eyebrow">{selectedCategory?.name ?? "CURSO"} · {selectedSport?.name ?? "DEPORTE"}</span><h3>Calendario y resultados</h3></div><div className="list-heading-actions"><button className="button button-outline" disabled={!selectedMatches.length} onClick={() => csvDownload("calendario-juegos-internos.csv", [["Curso", "Deporte", "Fase", "Fecha", "Hora", "Local", "Marcador", "Visitante", "Lugar", "Estado"], ...selectedMatches.map((match) => [match.categoryName, match.sportName, groupLabel(match), match.matchDate ?? "", match.matchTime ?? "", match.homeName ?? "Descansa", match.scoreHome ?? "", match.awayName ?? "", match.venue, match.status === "finished" ? "Jugado" : match.status === "bye" ? "Descanso" : "Pendiente"])])}><ArrowDownToLine size={15} /> Descargar CSV</button><button className="button button-outline" disabled={!selectedMatches.length} onClick={() => window.print()}><FileSpreadsheet size={15} /> Imprimir</button></div></div>
          {matchGroups.length ? <div className="round-list">{matchGroups.map(([key, matches]) => <section className="round-section" key={key}><div className="round-heading"><span>{groupLabel(matches[0])}</span><small>{matches.filter((match) => match.status === "finished").length}/{matches.filter((match) => match.status !== "bye").length} jugados</small></div><div className="match-list">{matches.map(renderMatchCard)}</div></section>)}</div> : <Card><EmptyState icon={Shuffle} title="Todavía no hay sorteo" text="Inscribe dos o más equipos para generar los enfrentamientos de esta categoría y deporte." /></Card>}
          {completedLeague && state.accessRole === "master" && <Card className="advance-card"><div><span className="eyebrow">PRIMERA FASE COMPLETA</span><h3>¿Listos para definir a los finalistas?</h3><p>{selectedTeams.length >= 4 ? "Clasifican los cuatro mejores a semifinales." : "Los dos mejores equipos pasan a la final."}</p></div><button className="button button-primary" disabled={saving} onClick={() => void act({ action: "advance", categoryId, sportId })}>Generar fase final <ArrowRight size={16} /></button></Card>}
        </>
      );
    }

    if (page === "posiciones") {
      return (
        <>
          <div className="filters-row">
            <label>Curso<select value={categoryId} onChange={(event) => setCategoryId(event.target.value)}>{activeCategories.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
            <label>Deporte<select value={sportId} onChange={(event) => setSportId(event.target.value)}>{activeSports.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
            <button className="button button-outline filter-add" disabled={!standingRows.length} onClick={() => csvDownload(`posiciones-${selectedCategory?.name ?? "curso"}-${selectedSport?.name ?? "deporte"}.csv`, [["Posición", "Equipo", "PJ", "G", "E", "P", "A favor", "En contra", "Diferencia", "Puntos"], ...standingRows.map((row, index) => [index + 1, row.name, row.played, row.wins, row.draws, row.losses, row.scored, row.conceded, row.difference, row.points])])}><ArrowDownToLine size={15} /> Exportar tabla</button>
          </div>
          <Card className="standings-card">
            <div className="section-heading"><div><span className="eyebrow">CLASIFICACIÓN</span><h3>{selectedCategory?.name ?? "Curso"} · {selectedSport?.name ?? "Deporte"}</h3></div><span className="live-tag"><span /> Actualizada automáticamente</span></div>
            {standingRows.length ? <div className="table-scroll"><table className="standings-table"><thead><tr><th>Pos.</th><th>Equipo</th><th>PJ</th><th>G</th><th>E</th><th>P</th><th>AF</th><th>EC</th><th>Dif.</th><th>Pts</th></tr></thead><tbody>{standingRows.map((row, index) => <tr key={row.id} className={index < 3 ? `top-row top-row-${index + 1}` : ""}><td><span className={`position-number ${index < 3 ? `position-${index + 1}` : ""}`}>{String(index + 1).padStart(2, "0")}</span></td><td><div className="standing-team"><span className="team-dot" style={{ background: row.jerseyColor ?? "#1c6b51" }} /><strong>{row.name}</strong></div></td><td>{row.played}</td><td>{row.wins}</td><td>{row.draws}</td><td>{row.losses}</td><td>{row.scored}</td><td>{row.conceded}</td><td className={row.difference > 0 ? "positive-diff" : row.difference < 0 ? "negative-diff" : ""}>{row.difference > 0 ? "+" : ""}{row.difference}</td><td><strong className="points-value">{row.points}</strong></td></tr>)}</tbody></table></div> : <EmptyState icon={Medal} title="La tabla aparecerá con los equipos" text="Registra paralelos y realiza el sorteo. Al guardar resultados, la clasificación se actualizará sola." />}
            <div className="table-note"><CircleHelp size={15} /><span>Desempates: puntos de competición, enfrentamiento directo, diferencia de goles / puntos y a favor.</span></div>
          </Card>
          <div className="standings-bottom-grid">
            <Card className="scoring-card"><span className="eyebrow">PUNTUACIÓN ACTUAL</span><h3>Reglas de {selectedSport?.name ?? "este deporte"}</h3><div className="rule-chips"><span><strong>{selectedSport?.winPoints ?? 0}</strong> ganar</span><span><strong>{selectedSport?.drawPoints ?? 0}</strong> empatar</span><span><strong>{selectedSport?.lossPoints ?? 0}</strong> perder</span></div>{state.accessRole === "master" ? <button className="text-button" onClick={() => enterPage("configuracion")}>Editar reglas <ArrowRight size={15} /></button> : null}</Card>
            {selectedMatches.some((match) => match.phase === "semifinal" || match.phase === "final") ? <Card className="finals-card"><span className="eyebrow">ELIMINATORIAS</span><h3>Cuadro final</h3><p>Revisa los cruces y registra los resultados en “Sorteos y partidos”.</p><button className="text-button" onClick={() => enterPage("partidos")}>Abrir partidos <ArrowRight size={15} /></button></Card> : <Card className="finals-card"><span className="eyebrow">SIGUIENTE PASO</span><h3>{completedLeague ? "Genera la fase final" : "Completa los partidos"}</h3><p>{completedLeague ? "El sistema toma automáticamente los equipos mejor ubicados." : "Cuando termines la primera fase, podrás crear semifinales y final."}</p><button className="text-button" onClick={() => enterPage("partidos")}>Ver partidos <ArrowRight size={15} /></button></Card>}
          </div>
        </>
      );
    }

    if (page === "inscripciones") {
      return <InscripcionesPanel onPendingChange={updatePendingCount} />;
    }

    return (
      <>
        <SettingsPanel state={state} saving={saving} act={act} credential={issuedCredential} onClearCredential={() => setIssuedCredential(null)} />
      </>
    );
  })();

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileMenu ? "sidebar-open" : ""}`}>
        <div className="brand-lockup"><Image className="brand-logo" src="/logo-ue-guaranda.png" width={52} height={40} alt="Escudo de la Unidad Educativa Guaranda" unoptimized /><div><strong>Juegos Internos</strong><small>UNIDAD EDUCATIVA GUARANDA</small></div></div>
        <div className="sidebar-caption">CAMPEONATO</div>
        <nav className="main-nav" aria-label="Navegación principal">{visibleNavItems.map((item) => { const Icon = item.icon; return <button key={item.id} className={`nav-item ${page === item.id ? "nav-active" : ""}`} onClick={() => enterPage(item.id)}><Icon size={18} /><span>{item.label}</span>{item.id === "partidos" && pending > 0 ? <em>{pending}</em> : null}{item.id === "inscripciones" && state.pendingRegistrations > 0 ? <em>{state.pendingRegistrations}</em> : null}</button>; })}</nav>
        <div className="sidebar-spacer" />
        <div className="sidebar-help"><span><CircleHelp size={18} /></span><strong>¿Necesitas ayuda?</strong><small>Este sistema organiza el torneo por curso y deporte.</small><button onClick={() => showNotice(state.accessRole === "master" ? "Para inscribir equipos, abre Equipos y agrega cada paralelo en su deporte." : "Abre Sorteos y partidos, elige el encuentro y pulsa Registrar marcador.", "info")}>Ver guía rápida <ArrowRight size={14} /></button></div>
        <div className="sidebar-footer"><span className="online-dot" /> Guardado en la nube <small>Acceso privado</small></div>
      </aside>

      <div className="app-main">
        <header className="topbar">
          <button className="mobile-menu-button" onClick={() => setMobileMenu((open) => !open)} aria-label="Abrir menú"><Menu size={20} /></button>
          <div className="topbar-title"><span>{state.config.schoolName} <i>·</i> {state.config.season}</span><h1>{pageTitles[page]}</h1><p>{pageDescription[page]}</p></div>
      <div className="topbar-right"><InstallAppButton /><Link className="button button-outline results-link" href="/">Ver resultados</Link><span className="cloud-status"><span /> Guardado</span><div className="user-chip"><span className="user-avatar">{user.displayName.slice(0, 1).toUpperCase()}</span><span><strong>{user.displayName}</strong><small>{state.accessRole === "master" ? `Master · ${user.username}` : `Docente · ${user.username}`}</small></span><a href="/gestion?cambiarClave=1" title="Cambiar contraseña"><KeyRound size={15} /></a><a href={signOutHref} title="Cerrar sesión"><LogOut size={16} /></a></div></div>
        </header>
        {notice ? <div className={`notice notice-${notice.type}`} role="status"><span>{notice.type === "success" ? <CheckCircle2 size={17} /> : notice.type === "error" ? <CircleHelp size={17} /> : <Sparkles size={17} />}</span>{notice.message}<button onClick={() => setNotice(null)} aria-label="Cerrar aviso"><X size={15} /></button></div> : null}
        <main className="page-content">{pageContent}</main>
        <footer className="app-footer"><span>{state.config.schoolName}</span><span>Responsable: {state.config.areaResponsible} · Rector: {state.config.rector}</span><span>Juegos Internos {state.config.season}</span></footer>
      </div>

      {teamModal ? <TeamModal categories={activeCategories} sports={activeSports} selectedCategoryId={categoryId} selectedSportId={sportId} saving={saving} onClose={() => setTeamModal(false)} onSave={async (payload) => { const ok = await act(payload, "Equipo inscrito correctamente."); if (ok) setTeamModal(false); }} /> : null}
      {resultMatch ? <ResultModal match={resultMatch} sport={state.sports.find((item) => item.id === resultMatch.sportId)} saving={saving} onClose={() => setResultMatch(null)} onSave={async (payload) => { const ok = await act(payload, "Resultado registrado; la tabla se actualizó."); if (ok) setResultMatch(null); }} /> : null}
      {scheduleMatch && state.accessRole === "master" ? <ScheduleModal match={scheduleMatch} saving={saving} onClose={() => setScheduleMatch(null)} onSave={async (payload) => { const ok = await act(payload, "Horario actualizado."); if (ok) setScheduleMatch(null); }} /> : null}
    </div>
  );
}

function TeamModal({
  categories,
  sports,
  selectedCategoryId,
  selectedSportId,
  saving,
  onClose,
  onSave,
}: {
  categories: Category[];
  sports: Sport[];
  selectedCategoryId: string;
  selectedSportId: string;
  saving: boolean;
  onClose: () => void;
  onSave: (payload: Record<string, unknown>) => Promise<void>;
}) {
  const [color, setColor] = useState("#1c6b51");
  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="team-modal-title">
    <div className="modal-heading"><div><span className="eyebrow">INSCRIPCIÓN DE EQUIPO</span><h2 id="team-modal-title">Agregar un paralelo</h2></div><button className="icon-button" onClick={onClose} aria-label="Cerrar"><X size={19} /></button></div>
    <form className="modal-form" onSubmit={(event: FormEvent<HTMLFormElement>) => { event.preventDefault(); const data = new FormData(event.currentTarget); void onSave({ action: "add_team", categoryId: data.get("categoryId"), sportId: data.get("sportId"), parallel: data.get("parallel"), captain: data.get("captain"), teacher: data.get("teacher"), jerseyColor: color, roster: String(data.get("roster") ?? "").split(/\r?\n/).map((name) => name.trim()).filter(Boolean) }); }}>
      <div className="modal-grid"><label>Curso<select name="categoryId" defaultValue={selectedCategoryId}>{categories.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label><label>Deporte<select name="sportId" defaultValue={selectedSportId}>{sports.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label></div>
      <label>Paralelo<input name="parallel" autoFocus placeholder="Ejemplo: A" maxLength={12} required /></label>
      <div className="modal-grid"><label>Capitán o delegada/o<input name="captain" placeholder="Opcional" maxLength={80} /></label><label>Docente responsable<input name="teacher" placeholder="Opcional" maxLength={100} /></label></div>
      <label>Lista de jugadores <span className="label-note">opcional · un nombre por línea</span><textarea name="roster" rows={4} maxLength={4000} placeholder="Escribe un estudiante por línea" /></label>
      <label className="color-picker-label">Color del equipo <input type="color" value={color} onChange={(event) => setColor(event.target.value)} /><span>{color.toUpperCase()}</span></label>
      <div className="modal-actions"><button type="button" className="button button-outline" onClick={onClose}>Cancelar</button><button className="button button-primary" disabled={saving}><Plus size={16} /> {saving ? "Guardando…" : "Inscribir equipo"}</button></div>
    </form>
  </section></div>;
}

function ResultModal({ match, sport, saving, onClose, onSave }: { match: Match; sport?: Sport; saving: boolean; onClose: () => void; onSave: (payload: Record<string, unknown>) => Promise<void> }) {
  const oldSets = Array.isArray(match.detail?.sets) ? (match.detail.sets as Array<{ home?: number; away?: number }>) : [];
  const [home, setHome] = useState(match.scoreHome === null ? "" : String(match.scoreHome));
  const [away, setAway] = useState(match.scoreAway === null ? "" : String(match.scoreAway));
  const [penaltyHome, setPenaltyHome] = useState("");
  const [penaltyAway, setPenaltyAway] = useState("");
  const [sets, setSets] = useState([0, 1, 2].map((index) => ({ home: oldSets[index]?.home === undefined ? "" : String(oldSets[index].home), away: oldSets[index]?.away === undefined ? "" : String(oldSets[index].away) })));
  const isEcuavoley = match.sportId === "ecuavoley";
  const isFootball = match.sportId === "futbol";
  const isKnockout = match.phase !== "round_robin";
  const setCounts = sets.reduce((count, score) => {
    if (score.home === "" || score.away === "" || Number(score.home) === Number(score.away)) return count;
    return { home: count.home + (Number(score.home) > Number(score.away) ? 1 : 0), away: count.away + (Number(score.away) > Number(score.home) ? 1 : 0) };
  }, { home: 0, away: 0 });
  const tied = isEcuavoley ? setCounts.home === setCounts.away : home !== "" && away !== "" && Number(home) === Number(away);
  const invalidSet = sets.some((score) => score.home !== "" && score.away !== "" && Number(score.home) === Number(score.away));
  const save = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const scoreHome = isEcuavoley ? setCounts.home : Number(home);
    const scoreAway = isEcuavoley ? setCounts.away : Number(away);
    const winnerOverride = tied && isFootball && isKnockout && penaltyHome !== "" && penaltyAway !== "" && Number(penaltyHome) !== Number(penaltyAway)
      ? Number(penaltyHome) > Number(penaltyAway) ? match.homeTeamId : match.awayTeamId
      : null;
    void onSave({ action: "save_result", matchId: match.id, scoreHome, scoreAway, winnerOverride, detail: isEcuavoley ? { sets: sets.filter((set) => set.home !== "" && set.away !== "").map((set) => ({ home: Number(set.home), away: Number(set.away) })) } : isFootball && winnerOverride ? { penalties: { home: Number(penaltyHome), away: Number(penaltyAway) } } : {} });
  };
  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><section className="modal-card result-modal" role="dialog" aria-modal="true" aria-labelledby="result-modal-title">
    <div className="modal-heading"><div><span className="eyebrow">{phaseLabel(match.phase)} · {match.sportName}</span><h2 id="result-modal-title">{match.homeName} <span className="heading-versus">vs</span> {match.awayName}</h2></div><button className="icon-button" onClick={onClose} aria-label="Cerrar"><X size={19} /></button></div>
    <form className="modal-form" onSubmit={save}>
      {isEcuavoley ? <div className="sets-entry"><div className="score-labels"><span>Equipo</span><span>Sets por juego</span></div>{sets.map((set, index) => <div className="set-score-row" key={index}><span>Set {index + 1}</span><input aria-label={`Puntos local set ${index + 1}`} type="number" min="0" max="99" value={set.home} onChange={(event) => setSets((previous) => previous.map((item, i) => i === index ? { ...item, home: event.target.value } : item))} /><b>:</b><input aria-label={`Puntos visitante set ${index + 1}`} type="number" min="0" max="99" value={set.away} onChange={(event) => setSets((previous) => previous.map((item, i) => i === index ? { ...item, away: event.target.value } : item))} /></div>)}<div className="set-total"><span>Sets ganados</span><strong>{setCounts.home}</strong><span>:</span><strong>{setCounts.away}</strong></div>{invalidSet ? <small className="form-error">Un set no puede terminar empatado.</small> : null}</div> : <div className="score-entry"><div className="score-team"><span className="team-dot" style={{ background: match.homeColor ?? "#1c6b51" }} /><strong>{match.homeName}</strong><input type="number" required min="0" max="999" value={home} onChange={(event) => setHome(event.target.value)} aria-label={`Marcador de ${match.homeName}`} /></div><span className="score-colon">:</span><div className="score-team"><span className="team-dot" style={{ background: match.awayColor ?? "#d89637" }} /><strong>{match.awayName}</strong><input type="number" required min="0" max="999" value={away} onChange={(event) => setAway(event.target.value)} aria-label={`Marcador de ${match.awayName}`} /></div></div>}
      {isFootball && isKnockout && tied ? <div className="tie-break-panel"><strong>Eliminatoria empatada</strong><p>Registra los penales o el desempate para definir quién avanza.</p><div className="tie-break-inputs"><label>Penales {match.homeName}<input type="number" min="0" max="99" value={penaltyHome} required onChange={(event) => setPenaltyHome(event.target.value)} /></label><label>Penales {match.awayName}<input type="number" min="0" max="99" value={penaltyAway} required onChange={(event) => setPenaltyAway(event.target.value)} /></label></div></div> : null}
      {sport && !Boolean(sport.allowDraw) && !isEcuavoley && tied && !isFootball ? <p className="form-hint">El marcador debe definir un ganador. Registra el resultado final después del tiempo extra.</p> : null}
      {isEcuavoley ? <p className="form-hint">Ingresa los puntos de cada set. El ganador se calcula automáticamente por sets.</p> : <p className="form-hint">El resultado se guarda al finalizar. Las posiciones se recalculan automáticamente.</p>}
      <div className="modal-actions"><button type="button" className="button button-outline" onClick={onClose}>Cancelar</button><button className="button button-primary" disabled={saving || (isEcuavoley ? invalidSet || Math.max(setCounts.home, setCounts.away) < 2 || setCounts.home === setCounts.away : home === "" || away === "")}><CheckCircle2 size={16} /> {saving ? "Guardando…" : "Guardar resultado"}</button></div>
    </form>
  </section></div>;
}

function ScheduleModal({ match, saving, onClose, onSave }: { match: Match; saving: boolean; onClose: () => void; onSave: (payload: Record<string, unknown>) => Promise<void> }) {
  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="schedule-modal-title">
    <div className="modal-heading"><div><span className="eyebrow">{phaseLabel(match.phase)} · {match.sportName}</span><h2 id="schedule-modal-title">Editar horario</h2></div><button className="icon-button" onClick={onClose} aria-label="Cerrar"><X size={19} /></button></div>
    <p className="modal-context">{match.homeName} <span>vs</span> {match.awayName}</p>
    <form className="modal-form" onSubmit={(event: FormEvent<HTMLFormElement>) => { event.preventDefault(); const data = new FormData(event.currentTarget); void onSave({ action: "save_schedule", matchId: match.id, matchDate: data.get("matchDate"), matchTime: data.get("matchTime"), venue: data.get("venue") }); }}>
      <div className="modal-grid"><label>Fecha<input type="date" name="matchDate" required defaultValue={match.matchDate ?? localToday()} /></label><label>Hora<input type="time" name="matchTime" required defaultValue={match.matchTime ?? "08:00"} /></label></div>
      <label>Cancha o lugar<input name="venue" maxLength={100} defaultValue={match.venue === "Por asignar" ? "Cancha principal" : match.venue} /></label>
      <div className="modal-actions"><button type="button" className="button button-outline" onClick={onClose}>Cancelar</button><button className="button button-primary" disabled={saving}><Clock3 size={16} /> Guardar horario</button></div>
    </form>
  </section></div>;
}

function SettingsPanel({ state, saving, act, credential, onClearCredential }: { state: AppState; saving: boolean; act: (payload: Record<string, unknown>, successMessage?: string) => Promise<boolean>; credential: { username: string; password: string } | null; onClearCredential: () => void }) {
  const [categoryName, setCategoryName] = useState("");
  const [categoryOrder, setCategoryOrder] = useState(String(state.categories.length + 1));
  const [config, setConfig] = useState(state.config);
  return <div className="settings-layout">
    {state.accessRole === "master" ? <Card className="settings-card">
      <div className="section-heading"><div><span className="eyebrow">DATOS OFICIALES</span><h3>Información del campeonato</h3></div><span className="official-tag"><ShieldCheck size={14} /> Acceso privado</span></div>
      <form className="settings-form" onSubmit={(event: FormEvent<HTMLFormElement>) => { event.preventDefault(); void act({ action: "save_settings", ...config }, "Datos oficiales actualizados."); }}>
        <div className="settings-grid"><label>Nombre del campeonato<input value={config.tournamentName} onChange={(event) => setConfig({ ...config, tournamentName: event.target.value })} maxLength={100} required /></label><label>Año o período<input value={config.season} onChange={(event) => setConfig({ ...config, season: event.target.value })} maxLength={16} required /></label><label>Institución<input value={config.schoolName} onChange={(event) => setConfig({ ...config, schoolName: event.target.value })} maxLength={100} required /></label><label>Responsable del área<input value={config.areaResponsible} onChange={(event) => setConfig({ ...config, areaResponsible: event.target.value })} maxLength={100} required /></label><label>Rector<input value={config.rector} onChange={(event) => setConfig({ ...config, rector: event.target.value })} maxLength={100} required /></label></div>
        <div className="settings-actions"><small>Estos datos aparecerán en los reportes impresos.</small><button className="button button-primary" disabled={saving}><Check size={16} /> Guardar datos</button></div>
      </form>
    </Card> : null}

    {state.accessRole === "master" ? <Card className="settings-card">
      <div className="section-heading"><div><span className="eyebrow">CURSOS Y CATEGORÍAS</span><h3>Amplía los cursos participantes</h3></div><span className="count-badge">{state.categories.length} cursos</span></div>
      <div className="category-list">{state.categories.map((category) => {
        const teamCount = state.teams.filter((team) => team.categoryId === category.id).length;
        return <div className="category-row" key={category.id}><span className="category-level">{String(category.sortOrder).padStart(2, "0")}</span><strong>{category.name}</strong><small>{teamCount} equipos</small><button className="icon-button danger-on-hover" title="Eliminar curso" onClick={() => { if (window.confirm(`¿Eliminar la categoría ${category.name}?`)) void act({ action: "remove_category", id: category.id }); }}><X size={16} /></button></div>;
      })}</div>
      <form className="add-category-form" onSubmit={(event: FormEvent<HTMLFormElement>) => { event.preventDefault(); void act({ action: "add_category", name: categoryName, sortOrder: Number(categoryOrder) }, "Curso agregado.").then((ok) => { if (ok) { setCategoryName(""); setCategoryOrder(String(state.categories.length + 2)); } }); }}>
        <label>Nuevo curso o categoría<input value={categoryName} onChange={(event) => setCategoryName(event.target.value)} placeholder="Ejemplo: 1.º BGU o Inicial 2" maxLength={60} required /></label><label>Orden<input type="number" min="1" max="999" value={categoryOrder} onChange={(event) => setCategoryOrder(event.target.value)} required /></label><button className="button button-outline" disabled={saving}><Plus size={16} /> Agregar</button>
      </form>
    </Card> : null}

    {state.accessRole === "master" ? <Card className="settings-card rules-card">
      <div className="section-heading"><div><span className="eyebrow">REGLAMENTO</span><h3>Puntos por deporte</h3></div><span className="rule-edit-tag"><Settings2 size={14} /> Editable</span></div>
      <p className="settings-intro">Ajusta la puntuación a las reglas aprobadas por el colegio antes de realizar los sorteos.</p>
      <div className="rules-list">{state.sports.map((sport) => <SportRule key={sport.id} sport={sport} saving={saving} onSave={(rules) => act({ action: "save_sport_rules", sportId: sport.id, ...rules }, `Reglas de ${sport.name} guardadas.`)} />)}</div>
    </Card> : null}

    <TeacherAccessPanel state={state} saving={saving} act={act} credential={credential} onClearCredential={onClearCredential} />

    <Card className="privacy-card"><div className="privacy-icon"><ShieldCheck size={21} /></div><div><strong>Resultados en la portada pública</strong><p>La portada muestra equipos, marcadores, posiciones y horario de próximos partidos; no publica las listas de jugadores.</p></div><Link className="text-button" href="/">Abrir portada <ArrowRight size={14} /></Link></Card>
  </div>;
}

function TeacherAccessPanel({ state, saving, act, credential, onClearCredential }: { state: AppState; saving: boolean; act: (payload: Record<string, unknown>, successMessage?: string) => Promise<boolean>; credential: { username: string; password: string } | null; onClearCredential: () => void }) {
  const [displayName, setDisplayName] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [copied, setCopied] = useState(false);
  if (state.accessRole !== "master") return null;
  return <Card className="settings-card teacher-access-card">
    <div className="section-heading"><div><span className="eyebrow">USUARIOS Y CONTRASEÑAS</span><h3>Acceso de docentes</h3></div><span className="count-badge">{state.staffUsers.filter((item) => item.role === "docente" && Boolean(item.active)).length} habilitados</span></div>
    <p className="settings-intro">Crea el usuario y genera una contraseña temporal. Entrégasela directamente al docente: al entrar tendrá que elegir una contraseña personal. Su acceso solo permite registrar o corregir resultados.</p>
    <form className="teacher-add-form" onSubmit={(event: FormEvent<HTMLFormElement>) => { event.preventDefault(); void act({ action: "add_teacher", displayName, username, email }, "Cuenta creada. Copia y entrega la contraseña temporal al docente.").then((ok) => { if (ok) { setDisplayName(""); setUsername(""); setEmail(""); } }); }}>
      <label>Nombre del docente<input value={displayName} onChange={(event) => setDisplayName(event.target.value)} maxLength={100} placeholder="Nombre y apellido" required /></label>
      <label>Usuario para ingresar<input value={username} onChange={(event) => setUsername(event.target.value)} minLength={3} maxLength={32} pattern="[A-Za-z0-9._-]{3,32}" placeholder="Ejemplo: MariaLopez" required /></label>
      <label>Correo opcional<input type="email" value={email} onChange={(event) => setEmail(event.target.value)} maxLength={160} placeholder="docente@colegio.edu.ec" /></label>
      <button className="button button-primary" disabled={saving}><Plus size={16} /> Crear acceso</button>
    </form>
    {credential ? <div className="issued-credential" role="status">
      <div><span className="issued-credential-icon"><KeyRound size={18} /></span><div><strong>Contraseña temporal creada</strong><small>Se muestra solo ahora. Entrégala al docente y pídele que la cambie al ingresar.</small></div></div>
      <dl><div><dt>Usuario</dt><dd>{credential.username}</dd></div><div><dt>Contraseña temporal</dt><dd>{credential.password}</dd></div></dl>
      <div className="issued-credential-actions"><button className="button button-outline" onClick={() => { void navigator.clipboard.writeText(`Usuario: ${credential.username}\nContraseña temporal: ${credential.password}`).then(() => { setCopied(true); window.setTimeout(() => setCopied(false), 2500); }); }}><Copy size={14} /> {copied ? "Copiado" : "Copiar acceso"}</button><button className="text-button" onClick={onClearCredential}>Ocultar</button></div>
    </div> : null}
    <div className="teacher-list" role="list" aria-label="Cuentas de docentes">
      {state.staffUsers.filter((item) => item.role === "docente").map((item) => <div className="teacher-row" role="listitem" key={item.email}>
        <span className="teacher-avatar">{initials(item.displayName || item.username || item.email)}</span><div className="teacher-row-info"><strong>{item.displayName}</strong><small>{item.username ? `Usuario: ${item.username}${item.email.endsWith(".invalid") ? "" : ` · ${item.email}`}` : item.email}</small></div>
        <span className="count-badge">Solo resultados</span><span className={`teacher-state ${Boolean(item.active) ? "teacher-state-active" : ""}`}>{Boolean(item.active) ? "Habilitado" : "Desactivado"}</span>
        {item.username && Boolean(item.active) ? <button className="button button-small button-outline" disabled={saving} onClick={() => void act({ action: "reset_teacher_password", email: item.email }, "Contraseña temporal restablecida. Entrégala directamente al docente.")}><KeyRound size={13} /> Nueva clave</button> : null}
        <button className={`button button-small ${Boolean(item.active) ? "button-outline" : "button-primary"}`} disabled={saving} onClick={() => void act({ action: "set_teacher_access", email: item.email, active: !Boolean(item.active) }, Boolean(item.active) ? "Acceso desactivado." : "Acceso habilitado.")}>{Boolean(item.active) ? "Desactivar" : "Habilitar"}</button>
      </div>)}
      {!state.staffUsers.some((item) => item.role === "docente" && item.username) ? <div className="teacher-empty">Todavía no agregas docentes. Completa el formulario para crear el primer acceso.</div> : null}
    </div>
  </Card>;
}

function initials(value: string) {
  return value.trim().split(/[\s@.]+/).filter(Boolean).slice(0, 2).map((part) => part[0]).join("").toUpperCase();
}

function SportRule({ sport, saving, onSave }: { sport: Sport; saving: boolean; onSave: (rules: Record<string, unknown>) => Promise<boolean> }) {
  const [win, setWin] = useState(String(sport.winPoints));
  const [draw, setDraw] = useState(String(sport.drawPoints));
  const [loss, setLoss] = useState(String(sport.lossPoints));
  const [allowDraw, setAllowDraw] = useState(Boolean(sport.allowDraw));
  return <form className="sport-rule-row" onSubmit={(event: FormEvent<HTMLFormElement>) => { event.preventDefault(); void onSave({ winPoints: Number(win), drawPoints: Number(draw), lossPoints: Number(loss), allowDraw }); }}>
    <span className="rule-sport-mark"><Trophy size={16} /></span><div className="rule-sport-name"><strong>{sport.name}</strong><small>{allowDraw ? "Permite empate en la primera fase" : "Partido debe terminar con ganador"}</small></div>
    <label>Ganar<input type="number" min="0" max="20" value={win} onChange={(event) => setWin(event.target.value)} /></label><label>Empatar<input type="number" min="0" max="20" value={draw} onChange={(event) => setDraw(event.target.value)} disabled={!allowDraw} /></label><label>Perder<input type="number" min="0" max="20" value={loss} onChange={(event) => setLoss(event.target.value)} /></label><label className="allow-draw"><input type="checkbox" checked={allowDraw} onChange={(event) => setAllowDraw(event.target.checked)} /> Permite empate</label><button className="icon-button save-rule" title={`Guardar reglas de ${sport.name}`} disabled={saving}><Check size={16} /></button>
  </form>;
}
