"use client";

import { FormEvent, useState } from "react";
import { ArrowLeft, Eye, EyeOff, KeyRound, LockKeyhole, ShieldCheck, UserRound } from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";

export default function AuthPortal({
  displayName,
  forcePasswordChange = false,
  initialError = "",
}: {
  displayName?: string;
  forcePasswordChange?: boolean;
  initialError?: string;
}) {
  const [needsChange, setNeedsChange] = useState(forcePasswordChange);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(initialError);
  const router = useRouter();

  async function handleLogin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const result = await response.json() as { error?: string; mustChangePassword?: boolean };
      if (!response.ok) throw new Error(result.error || "No se pudo iniciar sesión.");
      if (result.mustChangePassword) {
        setPassword("");
        setNeedsChange(true);
      }
      else window.location.reload();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "No se pudo iniciar sesión.");
    } finally {
      setBusy(false);
    }
  }

  async function handlePasswordChange(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    if (newPassword !== confirmPassword) {
      setError("Las contraseñas no coinciden.");
      return;
    }
    if (newPassword.length < 12) {
      setError("Usa al menos 12 caracteres para tu nueva contraseña.");
      return;
    }
    setBusy(true);
    try {
      const response = await fetch("/api/auth/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ newPassword }),
      });
      const result = await response.json() as { error?: string };
      if (!response.ok) throw new Error(result.error || "No se pudo guardar la nueva contraseña.");
      router.replace("/gestion");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "No se pudo guardar la nueva contraseña.");
    } finally {
      setBusy(false);
    }
  }

  return <main className="auth-page">
    <div className="auth-orbit auth-orbit-one" /><div className="auth-orbit auth-orbit-two" />
    <section className="auth-card">
      <Link className="auth-brand" href="/">
        <Image src="/logo-ue-guaranda.png" alt="Escudo Unidad Educativa Guaranda" width={51} height={46} unoptimized />
        <span><strong>Juegos Internos</strong><small>UNIDAD EDUCATIVA GUARANDA</small></span>
      </Link>
      <div className="auth-card-body">
        <span className="auth-icon">{needsChange ? <KeyRound size={23} /> : <LockKeyhole size={23} />}</span>
        <span className="auth-eyebrow">JUEGOS INTERNOS · EDICIÓN 2026–2027</span>
        <h1>{needsChange ? "Crea tu contraseña personal" : "Ingreso de docentes"}</h1>
        <p>{needsChange
          ? `Hola${displayName ? `, ${displayName}` : ""}. Elige una contraseña personal de al menos 12 caracteres para proteger tu acceso.`
          : "Ingresa con el usuario y la contraseña que te entregó la persona Master del campeonato."}</p>

        {needsChange ? <form className="auth-form" onSubmit={handlePasswordChange}>
          <label>Nueva contraseña
            <div className="auth-password-wrap"><input autoComplete="new-password" type={showPassword ? "text" : "password"} value={newPassword} onChange={(event) => setNewPassword(event.target.value)} minLength={12} maxLength={128} required autoFocus /><button type="button" aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"} onClick={() => setShowPassword((value) => !value)}>{showPassword ? <EyeOff size={17} /> : <Eye size={17} />}</button></div>
          </label>
          <label>Repite la nueva contraseña<input autoComplete="new-password" type={showPassword ? "text" : "password"} value={confirmPassword} onChange={(event) => setConfirmPassword(event.target.value)} minLength={12} maxLength={128} required /></label>
          <div className="auth-password-note"><ShieldCheck size={15} /> Solo tú podrás conocer esta contraseña.</div>
          {error ? <div className="auth-error" role="alert">{error}</div> : null}
          <button className="auth-submit" disabled={busy}>{busy ? "Guardando…" : "Guardar y entrar"}</button>
        </form> : <form className="auth-form" onSubmit={handleLogin}>
          <label>Usuario
            <span className="auth-field-icon"><UserRound size={15} /><input autoComplete="username" value={username} onChange={(event) => setUsername(event.target.value)} maxLength={32} placeholder="Tu usuario" required autoFocus /></span>
          </label>
          <label>Contraseña
            <div className="auth-password-wrap"><input autoComplete="current-password" type={showPassword ? "text" : "password"} value={password} onChange={(event) => setPassword(event.target.value)} maxLength={128} placeholder="Tu contraseña" required /><button type="button" aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"} onClick={() => setShowPassword((value) => !value)}>{showPassword ? <EyeOff size={17} /> : <Eye size={17} />}</button></div>
          </label>
          {error ? <div className="auth-error" role="alert">{error}</div> : null}
          <button className="auth-submit" disabled={busy}>{busy ? "Ingresando…" : "Ingresar al panel"}</button>
        </form>}
        <div className="auth-card-footer"><Link href="/"><ArrowLeft size={15} /> Volver a resultados públicos</Link><span>Acceso individual y protegido</span></div>
      </div>
    </section>
  </main>;
}
